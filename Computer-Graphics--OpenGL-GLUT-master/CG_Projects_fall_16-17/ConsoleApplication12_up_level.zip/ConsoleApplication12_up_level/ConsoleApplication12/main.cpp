#include <iostream>
#include <String>
#include <stdlib.h> 
#include <time.h> 
#include <GL/glut.h>
#include <math.h>
#include "StdAfx.h"
#include <iostream>
#include <stdlib.h>

#include <GL/glut.h>

#include "imageloader.h"

using namespace std;




float x = 300 * 0.0033, y = 300 * 0.0025, d = (10.0*0.0033), w_h = 800 * 0.0025, w_w = 800 * 0.0033, s = 698 * 0.0033, t = 600 * 0.0025, a = 1, s1 = 250 * 0.0033, t1 = 200 * 0.0025;
float star_x[99], star_y[99];
int no_of_star = 20, i = 0, game_over = 0, score = 0;


double delay = 0, set_delay = 3000;
float enemy_ss_x[999999], enemy_ss_y[999999];
int enemy_ss_no = 0, start = 0;


float bullet_x[999999], bullet_y[999999];
int bullet_no = 0, start_bullet = 0;


int deleted_bullets[999999], destroyed_enemy_ss[999999], deleted_bullets_no = 0, destroyed_enemy_ss_no = 0;



bool* keySpecialStates = new bool[246];
bool* keyStates = new bool[256];


//value for Bitmap Font scroe txt
float x_bf = 0.12f*0.0033, y_bf = 0.10f*0.0025;



GLuint _textureId;

int level = 1;
int kill = 0;






// for text drawing

void drawBitmapText(char *string, float x, float y, float z)
{
	char *c;
	glRasterPos3f(x, y, z);

	for (c = string; *c != '\0'; c++)
	{
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, *c);
	}
}

void drawStrokeText(char*string, float x, float y, int z)
{
	char *c;
	glPushMatrix();
	glTranslatef(x, y + (8 * 0.0025), z);
	glScalef(x_bf, y_bf, z);

	for (c = string; *c != '\0'; c++)
	{
		glutStrokeCharacter(GLUT_STROKE_ROMAN, *c);
	}
	glPopMatrix();
}


//num to string 

string num_to_str(int num) {
	string s = "";
	do {
		int mod = num % 10;
		if (mod == 1) {
			s = '1' + s;
		}
		else if (mod == 2) {
			s = '2' + s;
		}
		else if (mod == 3) {
			s = '3' + s;
		}
		else if (mod == 4) {
			s = '4' + s;
		}
		else if (mod == 5) {
			s = '5' + s;
		}
		else if (mod == 6) {
			s = '6' + s;
		}
		else if (mod == 7) {
			s = '7' + s;
		}
		else if (mod == 8) {
			s = '8' + s;
		}
		else if (mod == 9) {
			s = '9' + s;
		}
		else if (mod == 0) {
			s = '0' + s;
		}
		num = num / 10;
	} while (num != 0);
	return s;
}


//! Draw Filled Circle to bitmap or passed bitmap 
void doCirclefill(int b_i, float x, float y, float radius) {
	glEnable(GL_BLEND);
	glColor4f(0.0, 0.0, 1.0, 0.0);
	float y1 = y;
	float x1 = x;
	glBegin(GL_TRIANGLES);
	for (int i = 0; i <= 360; i++)
	{
		float angle = (float)(((float)i) / 57.29577957795135);
		float x2 = x + (radius*(float)sin((float)angle));
		float y2 = y + (radius*(float)cos((float)angle));
		glVertex2f(x, y);
		glVertex2f(x1, y1);
		glVertex2f(x2, y2);
		y1 = y2;
		x1 = x2;
	}
	glEnd();
	glDisable(GL_BLEND);
}

void drawScene() {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

glPushMatrix();

	glTranslatef(0.0, 0.0, -5.0f);
	
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, _textureId);
	

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_QUADS);
	
	glNormal3f(0.0f, 0.0f, 1.0f);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(-1.0, -1.0, 0.0);

	glTexCoord2f(0.0, 5.0);
	glVertex3f(-1.0, 1.0, 0.0);

	glTexCoord2f(5.0, 5.0);
	glVertex3f(1.0, 1.0, 0.0);

	glTexCoord2f(5.0, 0.0);
	glVertex3f(1.0, -1.0, 0.0);
	
	glEnd();

	glPopMatrix();


	glDisable(GL_TEXTURE_2D);

	//texture end

	glPushMatrix();

	glTranslatef(-1.0, -1.0, -5.0f);

	//player
	glColor3f(0.0, 1.0, 0.0);
	doCirclefill(1, x + (40 * 0.0033), y, (6 * 0.0033));

	glEnd();

	glColor3f(1.0, 0.0, 0.0);
	glPointSize(2.0);
	glBegin(GL_QUADS);

	glVertex2f(x, y);
	glVertex2f(x + (8*0.0033), y + (2*0.0025));
	glVertex2f(x + (8*0.0033), y - (10*0.0025));
	glVertex2f(x, y - (8*0.0025));


	glColor3f(1.0, 1.0, 1.0);
	glVertex2f(x + (8*0.0033), y + (2*.0025));
	glVertex2f(x + (8 * 0.0033) + (50 * 0.0033), y - (2 * .0025));
	glVertex2f(x + (8 * 0.0033) + (50 * 0.0033), y - (6 * .0025));
	glVertex2f(x + (8*0.0033), y - (10*.0025));

	glColor3f(0.3, 0.5, 0.5);
	glVertex2f(x + (8*0.0033), y + (2*.0025));
	glVertex2f(x + (8 * 0.0033) - (2 * 0.0033), y + (2 * .0025) + (10 * .0025));
	glVertex2f(x + (8 * 0.0033) + (6 * 0.0033), y + (2 * .0025) + (8 * .0025));
	glVertex2f(x + (8 * 0.0033) + (6 * 0.0033) + (4 * 0.0033), y + (1 * .0025));
	glEnd();
	//player end


	//enemy spaceship generate

	delay = delay + 1;
	if (delay > set_delay) {
		srand(time(NULL));
		int ran_num = rand() % 10 + 1;
		float d1 = 90 * 0.0025, space = 0;
		for (int i = 0; i < ran_num; i++) {
			if (game_over == 1) break;
			enemy_ss_x[enemy_ss_no] = s + (((rand() % 90) * 0.0033) + (20 * 0.0025));
			enemy_ss_y[enemy_ss_no] = t - space;
			enemy_ss_no++;
			space = space + d1;
		}
		set_delay = rand() % 5000 + 2000;
		delay = 0;
	}
	//enemy spaceship generate end

	for (int i = start; i < enemy_ss_no; i++) {
		if (enemy_ss_x[i] -(0.05*0.0033) >= 0) {

			if (game_over == 0) enemy_ss_x[i] = enemy_ss_x[i] - (0.10* 0.0033*level);

			int found = 0;
			for (int j = 0; j < destroyed_enemy_ss_no; j++) {
				if (destroyed_enemy_ss[j] == i) found = 1;
			}
			if (found == 0) {
				if (x<enemy_ss_x[i] && x>enemy_ss_x[i] - (58 * 0.0033) && y> enemy_ss_y[i] - (10 * 0.0025) && y< enemy_ss_y[i] + (10 * 0.0025)) {
					game_over = 1;
				}
				if (x<enemy_ss_x[i] && x>enemy_ss_x[i] - (58 * 0.0033) && y - (8 * 0.0025)> enemy_ss_y[i] - (10 * 0.0025) && y - (8 * 0.0025)< enemy_ss_y[i] + (10 * 0.0025)) {
					game_over = 1;
				}
				if (x + (58 * 0.0033)<enemy_ss_x[i] && x + (58 * 0.0033)>enemy_ss_x[i] - (58 * 0.0033) && y - (2 * 0.0025)> enemy_ss_y[i] - (10 * 0.0025) && y - (2 * 0.0025)< enemy_ss_y[i] + (10 * 0.0025)) {
					game_over = 1;
				}
				if (x + (58 * 0.0025)<enemy_ss_x[i] && x + (58 * 0.0033)>enemy_ss_x[i] - (58 * 0.0033) && y - (6 * 0.0025)> enemy_ss_y[i] - (10 * 0.0025) && y - (6 * 0.0025)< enemy_ss_y[i] + (10 * 0.0025)) {
					game_over = 1;
				}

				glColor3f(0.0, 1.0, 0.0);
				doCirclefill(1, enemy_ss_x[i] - (40 * 0.0033), enemy_ss_y[i], (6 * 0.0025));
				glEnd();

				glColor3f(1.0, 0.0, 0.0);
				glPointSize(2.0);
				glBegin(GL_QUADS);

				glVertex2f(enemy_ss_x[i], enemy_ss_y[i]);
				glVertex2f(enemy_ss_x[i] - (8 * 0.0033), enemy_ss_y[i] + (2 * 0.0025));
				glVertex2f(enemy_ss_x[i] - (8 * 0.0033), enemy_ss_y[i] - (10 * 0.0025));
				glVertex2f(enemy_ss_x[i], enemy_ss_y[i] - (8 * 0.0025));


				glColor3f(1.0, 1.0, 1.0);
				glVertex2f(enemy_ss_x[i] - (8 * 0.0033), enemy_ss_y[i] + (2 * 0.0025));
				glVertex2f(enemy_ss_x[i] - (8 * 0.0033) - (50 * 0.0033), enemy_ss_y[i] - (2 * 0.0025));
				glVertex2f(enemy_ss_x[i] - (8 * 0.0033) - (50 * 0.0033), enemy_ss_y[i] - (6 * 0.0025));
				glVertex2f(enemy_ss_x[i] - (8 * 0.0033), enemy_ss_y[i] - (10 * 0.0025));

				glColor3f(0.3, 0.5, 0.5);
				glVertex2f(enemy_ss_x[i] - (8 * 0.0033), enemy_ss_y[i] + (2 * 0.0025));
				glVertex2f(enemy_ss_x[i] - (8 * 0.0033) - (2 * 0.0033), enemy_ss_y[i] + (2 * 0.0025) + (10 * 0.0025));
				glVertex2f(enemy_ss_x[i] - (8 * 0.0033) - (6 * 0.0033), enemy_ss_y[i] + (2 * 0.0025) + (8 * 0.0025));
				glVertex2f(enemy_ss_x[i] - (8 * 0.0033) - (6 * 0.0033) - (4 * 0.0033), enemy_ss_y[i] + (1 * 0.0025));

				glEnd();
			}
		}
		else {
			if (start + 1 <= enemy_ss_no) start++;
		}
	}


	for (int i = 0; i < bullet_no; i++) {
		int found = 0;
		for (int j = 0; j < deleted_bullets_no; j++) {
			if (deleted_bullets[j] == i) found = 1;
		}
		if (found == 0) {
			if (bullet_x[i] + (0.05*0.0033) <= w_w) {
				if (game_over == 0) bullet_x[i] = bullet_x[i] + (0.10*0.0033);
				for (int j = start; j < enemy_ss_no; j++) {
					int found = 0;
					for (int k = 0; k < destroyed_enemy_ss_no; k++) {
						if (destroyed_enemy_ss[k] == j) found = 1;
					}
					if (found == 0) {
						if (bullet_x[i]<enemy_ss_x[j] && bullet_x[i]>enemy_ss_x[j] - (58 * 0.0033) && bullet_y[i]>enemy_ss_y[j] - (10 * 0.0025) && bullet_y[i] < enemy_ss_y[j] + (5 * 0.0025)) {
							deleted_bullets[deleted_bullets_no] = i;
							deleted_bullets_no++;
							destroyed_enemy_ss[destroyed_enemy_ss_no] = j;
							destroyed_enemy_ss_no++;
							score = score + 3;
							kill++;
						}
					}
				}
				glColor3f(1.0, 1.0, 1.0);
				glPointSize(3.0);
				glBegin(GL_POINTS);
				glVertex2f(bullet_x[i], bullet_y[i]);
				glEnd();
			}
			else {
				if (start_bullet + 1 <= bullet_no) start_bullet++;
			}
		}
	}


	x_bf = 0.12f*0.0033, y_bf = 0.10f*0.0025;
	glColor3f(0, 1, 0);
	string ttd = "";
	ttd = ttd + "Score: " + num_to_str(score);
	char *a;
	a = &ttd[0];
	drawStrokeText(a, 280 * 0.0033, 750 * 0.0025, 0);

	//level up draw
	string ttd1 = "";
	ttd1 = ttd1 + "Level: " + num_to_str(level);
	char *a1;
	a1 = &ttd1[0];
	x_bf = 0.12f*0.0033, y_bf = 0.13f*0.0025;
	glColor3f(1, 1, 0);
	drawStrokeText(a1, 280 * 0.0033, 700 * 0.0025, 0);

	if (kill > 9) {
		level++;
		kill = 0;
	}
	//level up draw end



	if (game_over == 1) {
		x_bf = 0.32f*0.0033; y_bf = 0.30f*0.0025;
		glColor3f(1, 0, 0);
		drawStrokeText("Game Over", 200 * 0.0033, 240 * 0.0025, 0);
	}





	glPopMatrix();
	glutSwapBuffers();

	glutPostRedisplay();
}

GLuint loadTexture(Image* image) {
	GLuint textureId;
	glGenTextures(1, &textureId); //Make room for our texture
	glBindTexture(GL_TEXTURE_2D, textureId); //Tell OpenGL which texture to edit
	//Map the image to the texture
	glTexImage2D(GL_TEXTURE_2D,                //Always GL_TEXTURE_2D
				 0,                            //0 for now
				 GL_RGB,                       //Format OpenGL uses for image
				 image->width, image->height,  //Width and height
				 0,                            //The border of the image
				 GL_RGB, //GL_RGB, because pixels are stored in RGB format
				 GL_UNSIGNED_BYTE, //GL_UNSIGNED_BYTE, because pixels are stored
				                   //as unsigned numbers
				 image->pixels);               //The actual pixel data
	return textureId; //Returns the id of the texture
}

void initialize() {
	
	glClearColor(1.0, 1.0, 1.0, 1.0);
	glMatrixMode(GL_PROJECTION);
	gluPerspective(23.0, 1.00, 1.0, 200.0);
	Image* image = loadBMP("blue-queen-night-sky.bmp");
	
	_textureId = loadTexture(image);
	
	delete image;
}


void keySpecial(int key, int x1, int y1) {
	keySpecialStates[key] = true;
	if (keySpecialStates[GLUT_KEY_LEFT] && x - d > 0) {
		if (game_over == 0) x = x - d;
	}
	else if (keySpecialStates[GLUT_KEY_RIGHT] && x + d < w_w - (200*0.0033)) {
		if (game_over == 0) x = x + d;
	}
	else if (keySpecialStates[GLUT_KEY_UP] && y + d < w_h - (20 * 0.0025)) {
		if (game_over == 0) y = y + d;
	}
	else if (keySpecialStates[GLUT_KEY_DOWN] && y - d > 0) {
		if (game_over == 0) y = y - d;
	}
}

void keySpecialUp(int key, int x, int y) {
	keySpecialStates[key] = false;
}

void keyPressed(unsigned char key, int x1, int y1) {
	keyStates[key] = true;
	if (keyStates['s']) {
		if (game_over == 0) bullet_x[bullet_no] = x + (58 * 0.0033);
		if (game_over == 0) bullet_y[bullet_no] = y - (4 * 0.0025);
		if (game_over == 0) bullet_no++;
	}
}

void keyUp(unsigned char key, int x, int y) {
	keyStates[key] = false;
}



void myInit(void) {
	

	glClearColor(0.0, 0.0, 0.0, 0.0);
	glColor3f(1.0f, 1.0f, 1.0f);
	glPointSize(2.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0, 800.0, 0.0, 600.0);

	
}









void main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(800, 600);
	
	glutCreateWindow("Textures");
	initialize();
	//lightSetting();
	glutDisplayFunc(drawScene);

	glutSpecialFunc(keySpecial);
	glutSpecialUpFunc(keySpecialUp);

	glutKeyboardFunc(keyPressed);
	glutKeyboardUpFunc(keyUp);

	keySpecialStates[GLUT_KEY_LEFT] = false;
	keySpecialStates[GLUT_KEY_RIGHT] = false;
	keySpecialStates[GLUT_KEY_UP] = false;
	keySpecialStates[GLUT_KEY_DOWN] = false;

	keyStates['s'] = false;

	glutMainLoop();
	//return 0;
}









