#include <windows.h>
#include <iostream>
#include <string.h>
#include<time.h>
#include <stdlib.h>
#include <string>
#include <GL/glut.h>
#include "imageloader.h"
using namespace std;


GLuint _textureId;
GLuint _textureId1;
GLuint _textureId2;
GLuint _textureId3;
GLuint _textureId4;
GLuint _textureId5;
GLuint _textureId6;
GLuint _textureId7;
GLuint _textureId8;
GLuint _textureId9;
GLuint _textureId10;
GLuint _textureId11;
GLuint _textureId12;
GLuint _textureId13;
GLuint _textureId14;



static int score=0;
static int flag=0;
float rx1=-2.0,ry1=-2.0,rx2=2.0,ry2=8.0;
float rrx1=-2.0,rry1=8.0,rrx2=2.0,rry2=18.0;
int road_status = 1;
float xrot,yrot,zrot=0.0;
float cx1,cx11,cy1=0;

int fff;string lannumber="";

int numberOfQuotes = 0, i;
char quote[6][80];

float lan1collision,lan2collision,lan3collision,lan4collision,orginialcarcollision;

int random1,random2,random3,random4;

float movex,movey=0.0;

float view = 10.0;

float movercary1,movercary2,movercary3,movercary4=0.0;

void road() {
glPushMatrix();

	glTranslatef(0.0, -1.0, -5.0f);

	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, _textureId);


	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_QUADS);

	glNormal3f(0.0f, 0.0f, 1.0f);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(rx1, ry1, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(rx2, ry1, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(rx2, ry2, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(rx1, ry2, 0.0);


	glEnd();

glPopMatrix();

}

/*void drivecar()
{
	if(movercary <= 9.7)
	{
		movercary+=0.0005;
	}

	if(movercary > 9.7)
	{

		movercary=-0.0005;
	}

}*/

void road2() {
	/*glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
	*/
glPushMatrix();

	glTranslatef(0.0, -1.0, -5.0f);

	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, _textureId);


	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_QUADS);

	glNormal3f(0.0f, 0.0f, 1.0f);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(rrx1, rry1, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(rrx2, rry1, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(rrx2, rry2, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(rrx1, rry2, 0.0);

	glEnd();

glPopMatrix();

}

void roadmove(){
	if(road_status==1){
		ry1 -= 0.005;
		ry2 -= 0.005;
		if(ry1 <= -12.0 && ry2 <=-2.0){
			ry1 = 8.0;
			ry2 =  18.0;
		}
	}
}
void roadmove2(){
	if(road_status == 1){
		rry1 -=0.005;
		rry2 -=0.005;
		if(rry1 <= -12.0 && rry2 <= -2.0){
			rry1 = 8.0;
			rry2 = 18.0;
		}
	}
}

void car() {
glPushMatrix();

	glBindTexture(GL_TEXTURE_2D, _textureId1);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glTranslatef(0.0+movex, 1.1+movey, -5.0f);

	orginialcarcollision=1.1+movey;

	glBegin(GL_QUADS);

	glNormal3f(0.0f, 0.0f, 1.0f);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(-1.0, -4.0, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(-1.0, -3.0, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(-.20, -3.0, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(-.20, -4.0, 0.0);

	glEnd();


glPopMatrix();

}

void gameover()
{
	glBindTexture(GL_TEXTURE_2D, _textureId14);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glTranslatef(0.0, 1.1, -5.0f);

	///orginialcarcollision=1.1+movey;

	glBegin(GL_QUADS);

	glNormal3f(0.0f, 0.0f, 1.0f);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(-1.0, -4.0, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(-1.0, -3.0, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(-.20, -3.0, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(-.20, -4.0, 0.0);

	glEnd();


    glPopMatrix();
}


void opponentcar(int x) {

	if(x==0)
	{
    glPushMatrix();

	glBindTexture(GL_TEXTURE_2D, _textureId1);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glTranslatef(0.0, 1.1, -5.0f);

	glBegin(GL_QUADS);

	glNormal3f(0.0f, 0.0f, 1.0f);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(cx1-1.0, cy1-4.0, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(cx1-1.0,cy1-3.0, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(cx1-.20, cy1-3.0, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(cx1-.20, cy1-4.0, 0.0);

	glEnd();

    glPopMatrix();
	}

	if(x==1)
	{
    glPushMatrix();

	glBindTexture(GL_TEXTURE_2D, _textureId2);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glTranslatef(0.0, 1.1, -5.0f);

	glBegin(GL_QUADS);

	glNormal3f(0.0f, 0.0f, 1.0f);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(cx1-1.0, cy1-4.0, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(cx1-1.0, cy1-3.0, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(cx1-.20, cy1-3.0, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(cx1-.20, cy1-4.0, 0.0);

	glEnd();

    glPopMatrix();
	}

	if(x==2)
	{
    glPushMatrix();

	glBindTexture(GL_TEXTURE_2D, _textureId3);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glTranslatef(0.0, 1.1, -5.0f);

	glBegin(GL_QUADS);

	glNormal3f(0.0f, 0.0f, 1.0f);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(cx1-1.0, cy1-4.0, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(cx1-1.0, cy1-3.0, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(cx1-.20, cy1-3.0, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(cx1-.20, cy1-4.0, 0.0);

	glEnd();

    glPopMatrix();
	}

	if(x==3)
	{
    glPushMatrix();

	glBindTexture(GL_TEXTURE_2D, _textureId4);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glTranslatef(0.0, 1.1, -5.0f);

	glBegin(GL_QUADS);

	glNormal3f(0.0f, 0.0f, 1.0f);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(cx1-1.0, cy1-4.0, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(cx1-1.0, cy1-3.0, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(cx1-.20, cy1-3.0, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(cx1-.20, cy1-4.0, 0.0);

	glEnd();

    glPopMatrix();
	
	}

	if(x==4)
	{
    glPushMatrix();

	glBindTexture(GL_TEXTURE_2D, _textureId5);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glTranslatef(0.0, 1.1, -5.0f);

	glBegin(GL_QUADS);

	glNormal3f(0.0f, 0.0f, 1.0f);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(cx1-1.0, cy1-4.0, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(cx1-1.0, cy1-3.0, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(cx1-.20, cy1-3.0, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(cx1-.20, cy1-4.0, 0.0);

	glEnd();

    glPopMatrix();
	
	}

	if(x==5)
	{
    glPushMatrix();

	glBindTexture(GL_TEXTURE_2D, _textureId6);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glTranslatef(0.0, 1.1, -5.0f);

	glBegin(GL_QUADS);

	glNormal3f(0.0f, 0.0f, 1.0f);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(cx1-1.0, cy1-4.0, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(cx1-1.0, cy1-3.0, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(cx1-.20, cy1-3.0, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(cx1-.20, cy1-4.0, 0.0);

	glEnd();

    glPopMatrix();
	
	}

	if(x==6)
	{
    glPushMatrix();

	glBindTexture(GL_TEXTURE_2D, _textureId7);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glTranslatef(0.0, 1.1, -5.0f);

	glBegin(GL_QUADS);

	glNormal3f(0.0f, 0.0f, 1.0f);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(cx1-1.0, cy1-4.0, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(cx1-1.0, cy1-3.0, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(cx1-.20, cy1-3.0, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(cx1-.20, cy1-4.0, 0.0);

	glEnd();

    glPopMatrix();
	
	}

	if(x==7)
	{
    glPushMatrix();

	glBindTexture(GL_TEXTURE_2D, _textureId8);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glTranslatef(0.0, 1.1, -5.0f);

	glBegin(GL_QUADS);

	glNormal3f(0.0f, 0.0f, 1.0f);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(cx1-1.0, cy1-4.0, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(cx1-1.0, cy1-3.0, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(cx1-.20, cy1-3.0, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(cx1-.20, cy1-4.0, 0.0);

	glEnd();

    glPopMatrix();
	}

	if(x==8)
	{
    glPushMatrix();

	glBindTexture(GL_TEXTURE_2D, _textureId9);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glTranslatef(0.0, 1.1, -5.0f);

	glBegin(GL_QUADS);

	glNormal3f(0.0f, 0.0f, 1.0f);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(cx11-1.0, cy1-4.0, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(cx11-1.0, cy1-3.0, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(cx11-.20, cy1-3.0, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(cx11-.20, cy1-4.0, 0.0);

	glEnd();
    glPopMatrix();
	
	}

    if(x==9)
	{
    glPushMatrix();

	glBindTexture(GL_TEXTURE_2D, _textureId10);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glTranslatef(0.0, 1.1, -5.0f);

	glBegin(GL_QUADS);

	glNormal3f(0.0f, 0.0f, 1.0f);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(cx1-1.0, cy1-4.0, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(cx1-1.0, cy1-3.0, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(cx1-.20, cy1-3.0, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(cx1-.20, cy1-4.0, 0.0);

	glEnd();

    glPopMatrix();
	}

    if(x==10)
	{
    glPushMatrix();

	glBindTexture(GL_TEXTURE_2D, _textureId11);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glTranslatef(0.0, 1.1, -5.0f);

	glBegin(GL_QUADS);

	glNormal3f(0.0f, 0.0f, 1.0f);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(cx1-1.0, cy1-4.0, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(cx1-1.0, cy1-3.0, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(cx1-.20, cy1-3.0, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(cx1-.20, cy1-4.0, 0.0);

	glEnd();

    glPopMatrix();
	}

    if(x==11)
	{
    glPushMatrix();

	glBindTexture(GL_TEXTURE_2D, _textureId12);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glTranslatef(0.0, 1.1, -5.0f);

	glBegin(GL_QUADS);

	glNormal3f(0.0f, 0.0f, 1.0f);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(cx1-1.0, cy1-4.0, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(cx1-1.0, cy1-3.0, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(cx1-.20, cy1-3.0, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(cx1-.20, cy1-4.0, 0.0);

	glEnd();

    glPopMatrix();
	}

}



GLuint loadTexture(Image* image) {
	GLuint textureId;
	glGenTextures(1, &textureId); //Make room for our texture
	glBindTexture(GL_TEXTURE_2D, textureId); //Tell OpenGL which texture to edit
	//Map the image to the texture
	glTexImage2D(GL_TEXTURE_2D,                //Always GL_TEXTURE_2D
				 0,                            //0 for now
				 GL_RGB,                       //Format OpenGL uses for image
				 image->width, image->height,  //Width and height
				 0,                            //The border of the image
				 GL_RGB, //GL_RGB, because pixels are stored in RGB format
				 GL_UNSIGNED_BYTE, //GL_UNSIGNED_BYTE, because pixels are stored
				                   //as unsigned numbers
				 image->pixels);               //The actual pixel data
	return textureId; //Returns the id of the texture
}

void initialize() {

	glClearColor(2.0, 1.0, 1.0, 1.0);
	glMatrixMode(GL_PROJECTION);
	gluPerspective(60.0, 1.00, 1.0, 200.0);

	Image* image = loadBMP("road.bmp");
	Image* image1 = loadBMP("n.bmp");
	Image* image2 = loadBMP("car2.bmp");
	Image* image3 = loadBMP("car3.bmp");
	Image* image5 = loadBMP("car5.bmp");
	Image* image6 = loadBMP("car6.bmp");
	Image* image7 = loadBMP("car7.bmp");
	Image* image8 = loadBMP("car8.bmp");
	Image* image9 = loadBMP("car9.bmp");
	Image* image10 = loadBMP("car10.bmp");
	Image* image11 = loadBMP("police.bmp");
	Image* image12 = loadBMP("truck.bmp");
	Image* image13 = loadBMP("bus.bmp");
    Image* image14 = loadBMP("game-over.bmp");

	_textureId = loadTexture(image);
	_textureId1 = loadTexture(image1);
	_textureId2 = loadTexture(image2);
	_textureId3 = loadTexture(image3);
	_textureId4 = loadTexture(image5); 
    _textureId5 = loadTexture(image6);
    _textureId6 = loadTexture(image7);
    _textureId7 = loadTexture(image8);
    _textureId8 = loadTexture(image9);
    _textureId9 = loadTexture(image10);
	_textureId10 = loadTexture(image11);
	_textureId11 = loadTexture(image12);
	_textureId12 = loadTexture(image13);
	_textureId14 = loadTexture(image14);

	delete image;
	delete image1;
	delete image2;
	delete image3;
	delete image5;
	delete image6;
	delete image7;
	delete image8;
	delete image9;
	delete image10;
	delete image11;
	delete image12;
	delete image13;
	delete image14;
}


void lightSetting()
{

	GLfloat ambientIntensity[4] = {0.6, 0.6, 0.6, 1.0};

	GLfloat position[4] = {0.0, 1.0, 0.0, 0.0};

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_COLOR_MATERIAL);

	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_NORMALIZE);


	glLightfv(GL_LIGHT0, GL_AMBIENT, ambientIntensity);

	glLightfv(GL_LIGHT0, GL_POSITION, position);
}

GLfloat UpwardsScrollVelocity = -10.0;

void timeTick(void)
{
	if (UpwardsScrollVelocity< -600)
		view -= 0.000011;
	if (view < 0) { view = 20; UpwardsScrollVelocity = -10.0; }
	//  exit(0);
	UpwardsScrollVelocity -= 0.1;
	glutPostRedisplay();
}

void RenderToDisplay()
{
	int l, lenghOfQuote, i;

	glTranslatef(0.0, -100, UpwardsScrollVelocity);
	glRotatef(-20, 1.0, 0.0, 0.0);
	glScalef(0.1, 0.1, 0.1);

	for (l = 0; l<numberOfQuotes; l++)
	{
		lenghOfQuote = (int)strlen(quote[l]);
		glPushMatrix();
		glTranslatef(-(lenghOfQuote * 37), -(l * 200), 0.0);
		for (i = 0; i < lenghOfQuote; i++)
		{
			glColor3f((UpwardsScrollVelocity / 10) + 300 + (l * 10), (UpwardsScrollVelocity / 10) + 300 + (l * 10), 0.0);
			glutStrokeCharacter(GLUT_STROKE_ROMAN, quote[l][i]);
		}
		glPopMatrix();
	}
}

void myDisplayFunction(void)
{
	glClear(GL_COLOR_BUFFER_BIT);
	glLoadIdentity();
	gluLookAt(0.0, 30.0, 100.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
	RenderToDisplay();
	glutSwapBuffers();

	RenderToDisplay();
	glutSwapBuffers();
}

void lancheck(float x)
{
	float y11=-1.22;
	float y2=0.0;
	float y3=1.22;
	float y4=2.44;

	if(x==y11)
		lannumber="lan1";
	else if(x==y3)
		lannumber="lan3";
	else if(x==y4)
		lannumber="lan4";
	else
		lannumber="lan2";

}
void reshape(int w, int h)
{
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60, 1.0, 1.0, 3200);
	glMatrixMode(GL_MODELVIEW);
}

int winner(char a)
{
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(1360, 750);
	glutCreateWindow("GAME OVER");
	glClearColor(0.0, 0.0, 0.0, 1.0);
	glLineWidth(3);
	char c=char(score);
	strcpy_s(quote[0], "Game Over");
	numberOfQuotes = 5;
	glutDisplayFunc(myDisplayFunction);
	glutReshapeFunc(reshape);
	glutIdleFunc(timeTick);
	glutMainLoop();
	return 0;
}

void mydisplay(){
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glPushMatrix();

	glScalef(0.7,1,1);
	car();
	glPopMatrix();

	lancheck(movex);

	//cout<<orginialcarcollision <<"fuck cg"<<lan4collision<<endl;

	  float jj=0.02;
	
	if( lannumber=="lan1" && orginialcarcollision > 1.1 && lan1collision > 3.64)
	{	
		winner('1');
	}
	else if( lannumber=="lan1" && orginialcarcollision > 1.15 && lan1collision > 3.59)
	{
		winner('1');
		//gameover();
	}
	else if( lannumber=="lan1" && orginialcarcollision > 1.20 && lan1collision > 3.52)
	{
		winner('1');
	}
	else if( lannumber=="lan1" && orginialcarcollision > 1.25 && lan1collision > 3.45)
	{
		winner('1');
	  
	}
	else if( lannumber=="lan1" && orginialcarcollision > 1.3 && lan1collision > 3.39)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan1" && orginialcarcollision > 1.35 && lan1collision > 3.34)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan1" && orginialcarcollision > 1.40 && lan1collision > 3.29)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan1" && orginialcarcollision > 1.45 && lan1collision > 3.24)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan1" && orginialcarcollision > 1.50 && lan1collision > 3.19)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan1" && orginialcarcollision > 1.55 && lan1collision > 3.14)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan1" && orginialcarcollision > 1.60 && lan1collision > 3.09)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan1" && orginialcarcollision > 1.65 && lan1collision > 3.04)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan1" && orginialcarcollision > 1.70 && lan1collision > 2.99)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan1" && orginialcarcollision > 1.75 && lan1collision > 2.94)
	{
		winner('1');
		  
	}
    else if( lannumber=="lan1" && orginialcarcollision > 1.80 && lan1collision > 2.89)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan1" && orginialcarcollision > 1.85 && lan1collision > 2.84)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan1" && orginialcarcollision > 1.90 && lan1collision > 2.79)
	{
		winner('1');
		  
	}
    else if( lannumber=="lan1" && orginialcarcollision > 1.95 && lan1collision > 2.74)
	{
		winner('1');
		  
	}
    else if( lannumber=="lan1" && orginialcarcollision > 2.00 && lan1collision > 2.69)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan1" && orginialcarcollision > 2.05 && lan1collision > 2.64)
	{
		winner('1');
		  
	}
     else if( lannumber=="lan1" && orginialcarcollision > 2.10 && lan1collision > 2.59)
	{
		winner('1');
		  
	}


    //for second lan

    else if( lannumber=="lan2" && orginialcarcollision > 2.10 && lan2collision > 2.69)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan2" && orginialcarcollision > 2.05 && lan2collision > 2.73)
	{
		winner('1');
		  
	}
    else if( lannumber=="lan2" && orginialcarcollision > 2.00 && lan2collision > 2.77)
	{
		winner('1');
		  
	}
    else if( lannumber=="lan2" && orginialcarcollision > 1.95 && lan2collision > 2.81)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan2" && orginialcarcollision > 1.90 && lan2collision > 2.85)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan2" && orginialcarcollision > 1.85 && lan2collision > 2.89)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan2" && orginialcarcollision > 1.80 && lan2collision > 2.93)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan2" && orginialcarcollision > 1.75 && lan2collision > 2.97)
	{
		winner('1');
		  
	}
    else if( lannumber=="lan2" && orginialcarcollision > 1.70 && lan2collision > 3.01)
	{
		winner('1');
		  
	}
    else if( lannumber=="lan2" && orginialcarcollision > 1.65 && lan2collision > 3.05)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan2" && orginialcarcollision > 1.60 && lan2collision > 3.09)
	{
		winner('1');
		  
	}
    else if( lannumber=="lan2" && orginialcarcollision > 1.55 && lan2collision > 3.13)
	{
		winner('1');
		  
	}
    else if( lannumber=="lan2" && orginialcarcollision > 1.50 && lan2collision > 3.17)
	{
		winner('1');
		  
	}
    else if( lannumber=="lan2" && orginialcarcollision > 1.45 && lan2collision > 3.21)
	{
		winner('1');
		  
	}
    else if( lannumber=="lan2" && orginialcarcollision > 1.40 && lan2collision > 3.25)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan2" && orginialcarcollision > 1.35 && lan2collision > 3.29)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan2" && orginialcarcollision > 1.30 && lan2collision > 3.33)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan2" && orginialcarcollision > 1.25 && lan2collision > 3.37)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan2" && orginialcarcollision > 1.20 && lan2collision > 3.41)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan2" && orginialcarcollision > 1.15 && lan2collision > 3.45)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan2" && orginialcarcollision > 1.10 && lan2collision > 3.49)
	{
		winner('1');
		  
	}

	//for third lan
    else if( lannumber=="lan3" && orginialcarcollision > 2.10 && lan3collision > 2.70)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan3" && orginialcarcollision > 2.05 && lan3collision > 2.74)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan3" && orginialcarcollision > 2.00 && lan3collision > 2.78)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan3" && orginialcarcollision > 1.95 && lan3collision > 2.82)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan3" && orginialcarcollision > 1.90 && lan3collision > 2.86)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan3" && orginialcarcollision > 1.85 && lan3collision > 2.90)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan3" && orginialcarcollision > 1.80 && lan3collision > 3.00)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan3" && orginialcarcollision > 1.75 && lan3collision > 2.94)
	{
		winner('1');
		  
	}
   else if( lannumber=="lan3" && orginialcarcollision > 1.70 && lan3collision > 2.98)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan3" && orginialcarcollision > 1.65 && lan3collision > 3.02)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan3" && orginialcarcollision > 1.60 && lan3collision > 3.06)
	{
		winner('1');
		  
	}
    else if( lannumber=="lan3" && orginialcarcollision > 1.55 && lan3collision > 3.10)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan3" && orginialcarcollision > 1.50 && lan3collision > 3.14)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan3" && orginialcarcollision > 1.45 && lan3collision > 3.18)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan3" && orginialcarcollision > 1.40 && lan3collision > 3.22)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan3" && orginialcarcollision > 1.35 && lan3collision > 3.26)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan3" && orginialcarcollision > 1.30 && lan3collision > 3.30)
	{
		winner('1');
		  
	}
    else if( lannumber=="lan3" && orginialcarcollision > 1.25 && lan3collision > 3.34)
	{
		winner('1');
		  
	}
   else if( lannumber=="lan3" && orginialcarcollision > 1.20 && lan3collision > 3.39)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan3" && orginialcarcollision > 1.15 && lan3collision > 3.43)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan3" && orginialcarcollision > 1.10 && lan3collision > 3.48)
	{
		winner('1');
		  
	}
 
	//for forth lan

   else if( lannumber=="lan4" && orginialcarcollision > 2.10 && lan4collision > 2.67)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan4" && orginialcarcollision > 2.05 && lan4collision > 2.74-jj)
	{
		winner('1');
		  
	}
    else if( lannumber=="lan4" && orginialcarcollision > 2.00 && lan4collision > 2.81-jj)
	{
		winner('1');
		  
	}
    else if( lannumber=="lan4" && orginialcarcollision > 1.95 && lan4collision > 2.88-jj)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan4" && orginialcarcollision > 1.90 && lan4collision > 2.95-jj)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan4" && orginialcarcollision > 1.85 && lan4collision > 3.02-jj)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan4" && orginialcarcollision > 1.80 && lan4collision > 3.09-jj)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan4" && orginialcarcollision > 1.75 && lan4collision > 3.16-jj)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan4" && orginialcarcollision > 1.70 && lan4collision > 3.23-jj)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan4" && orginialcarcollision > 1.65 && lan4collision > 3.30-jj)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan4" && orginialcarcollision > 1.60 && lan4collision > 3.37-jj)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan4" && orginialcarcollision > 1.55 && lan4collision > 3.44-jj)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan4" && orginialcarcollision > 1.50 && lan4collision > 3.51-jj)
	{
		winner('1');
		  
	}
   else if( lannumber=="lan4" && orginialcarcollision > 1.45 && lan4collision > 3.58-jj)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan4" && orginialcarcollision > 1.40 && lan4collision > 3.65-jj)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan4" && orginialcarcollision > 1.35 && lan4collision > 3.72-jj)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan4" && orginialcarcollision > 1.30 && lan4collision > 3.79-jj)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan4" && orginialcarcollision > 1.25 && lan4collision > 3.86-jj)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan4" && orginialcarcollision > 1.20 && lan4collision > 3.93-jj)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan4" && orginialcarcollision > 1.15 && lan4collision > 4.00-jj)
	{
		winner('1');
		  
	}
	else if( lannumber=="lan4" && orginialcarcollision > 1.10 && lan4collision > 4.07-0.07)
	{
		winner('1');
		  
	}

	//===========================

	//lan1

	glPushMatrix();
	glRotatef(-180,0.0,0.0,1.0);
	glScalef(0.56,0.9,1);
	glTranslatef(2.4, (-0.9)+movercary1, 1.0);

	lan1collision=-0.9+movercary1;

	opponentcar(0+random1);
	glPopMatrix();


	if(movercary1 <= 6.7)
	{
		movercary1+=0.0014;
	}

	if(movercary1 > 6.7)
	{
		movercary1=-0.0014;
		random1=rand()%11;
	}

	///=====================-1.5//-2.9//-3.8

    //lan2

	glPushMatrix();
	glRotatef(-180,0.0,0.0,1.0);
	glScalef(0.56,0.9,1);
	glTranslatef(1.2, (-0.9)+movercary2, 1.0);

	lan2collision=-0.9+movercary2;

	opponentcar(5+random2);
	glPopMatrix();

	if(movercary2 <= 6.7)
	{
		movercary2+=0.0008;
	}

	if(movercary2 > 6.7)
	{
		movercary2=-0.0008;
		random2=rand()%11;
	}

	///=====================

	//lan3

	glPushMatrix();

	glScalef(0.56,0.9,1);
	glRotatef(-180,0.0,0.0,1.0);
	glTranslatef(0.0, (-0.9)+movercary3, 1.0);

    lan3collision=-0.9+movercary3;

	opponentcar(7+random3);
	glPopMatrix();

	if(movercary3 <= 6.7)
	{
		movercary3+=0.0005;
	}

	if(movercary3 > 6.7)
	{
		movercary3=-0.0005;
		random3=rand()%11;
	}

	///=====================

	//lan4

	glPushMatrix();
	glScalef(0.56,0.9,1);
	glRotatef(-180,0.0,0.0,1.0);
	glTranslatef(-1.2, (-0.9)+movercary4, 1.0);

	lan4collision=-0.9+movercary4;

	opponentcar(5+random4);

	glPopMatrix();

	if(movercary4 <= 6.7)
	{
		movercary4+=0.0012;
	}

	if(movercary4 > 6.7)
	{
		movercary4=-0.0012;
		random4=rand()%11;
	}

	///=====================

	glPushMatrix();
	glScalef(0.8,1,1);
	road();
	road2();
	glPopMatrix();

	roadmove();
	roadmove2();

	glutSwapBuffers();
	glClearColor(0.957, 0.643, 0.376,0.0);
	glFlush();
	glutPostRedisplay();
}

void keyboardown(int key, int xx, int yy)
{
    switch (key){
        case GLUT_KEY_RIGHT:
			if(movex < 2.44)
				movex+=1.22;
			
            break;
		case GLUT_KEY_LEFT:
			if(movex > -1.22)
				movex-=1.22;

            break;

        case GLUT_KEY_UP:
			if(movey < 1.0)
			     movey+=0.05;

            break;

        case GLUT_KEY_DOWN:
			if(movey > 0.0)
                 movey-=0.05;

            break;


        default:
         break;
    }
}

int main(int argc, char** argv) 
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(800, 700);
	glutInitWindowPosition(0,0);
	glutCreateWindow("CG project");
	initialize();
	lightSetting();
	glutDisplayFunc(mydisplay);
	glutSpecialFunc(keyboardown);
	//glutKeyboardFunc(keyboard);
	//glutTimerFunc(2000, update, 0);
	glutMainLoop();
	return 0;
}