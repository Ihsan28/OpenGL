We have completed the following requirements - 

1 - Animation
2 - Texture Mapping
3 - Collision Detetction
4 - Score
5 - Health Bar
6 - Sound
7 - Menu Screen
8 - Pause Screen
9 - Game Over Screen
