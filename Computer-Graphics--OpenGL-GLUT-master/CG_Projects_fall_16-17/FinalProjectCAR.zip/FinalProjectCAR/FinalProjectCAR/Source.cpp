#include <glut.h>
#include "imageloader.h"

void display();
GLuint  _textureId;
GLuint  _textureId1;
GLuint  _textureId2;
GLuint  _textureId3;
GLuint  _textureId4;
GLuint  _textureId5;

int score, exit1 = 0;
float x, y;
float x1, y1 = 1000, x2 = 200, x3 = -200, y2 = 1500, y3 = 2000;
int time = 0;
typedef struct lines
{
	int x, y;
}linet;
linet line[2];
void createline()
{
	
	for (int i = 0;i<5;i++)
	{
		line[i].x = 0;
		line[i].y = i * 25;
	}
}

GLuint loadTexture(Image* image) {
	GLuint textureId;
	glGenTextures(1, &textureId); //Make room for our texture
	glBindTexture(GL_TEXTURE_2D, textureId); //Tell OpenGL which texture to edit
											 //Map the image to the texture
	glTexImage2D(GL_TEXTURE_2D,                //Always GL_TEXTURE_2D
		0,                            //0 for now
		GL_RGB,                       //Format OpenGL uses for image
		image->width, image->height,  //Width and height
		0,                            //The border of the image
		GL_RGB, //GL_RGB, because pixels are stored in RGB format
		GL_UNSIGNED_BYTE, //GL_UNSIGNED_BYTE, because pixels are stored
						  //as unsigned numbers
		image->pixels);               //The actual pixel data
	return textureId; //Returns the id of the texture
}
void enemy(float a, float b)
{
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, _textureId5);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glBegin(GL_QUADS);

	glColor3f(1, 1, 1);
	glTexCoord2i(0, 0);
	glVertex2f(-95 + a, 50 + b);
	glTexCoord2i(0, 1);
	glVertex2f(-95 + a, 100 + b);  //back side wheel
	glTexCoord2i(1, 1);
	glVertex2f(95 + a, 100 + b);
	glTexCoord2i(1, 0);
	glVertex2f(95 + a, 50 + b);
	glEnd();
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, _textureId5);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glBegin(GL_QUADS);
	glColor3f(1, 1, 1);
	glTexCoord2i(0, 0);
	glVertex2f(-95 + a, 150 + b);
	glTexCoord2i(0, 1);
	glVertex2f(-95 + a, 200 + b);//front side wheel
	glTexCoord2i(1, 1);
	glVertex2f(95 + a, 200 + b);
	glTexCoord2i(1, 0);
	glVertex2f(95 + a, 150 + b);
	glEnd();

	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, _textureId3);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glBegin(GL_QUADS);
	glColor3f(1, 0, 0);
	glTexCoord2i(0, 0);
	glVertex2f(-45 + a, 40 + b);
	glTexCoord2i(0, 1);
	glVertex2f(-45 + a, 250 + b);// middle part
	glTexCoord2i(1, 1);
	glVertex2f(45 + a, 250 + b);
	glTexCoord2i(1, 0);
	glVertex2f(45 + a, 40 + b);
	glEnd();
}

void sc(int a)
{
	int i, j, k;
	i = a / 100;
	j = a / 10 - i * 10;
	k = a - j * 10 - i * 100;
	glPushMatrix();

	glColor3f(0.0, 0.0, 0.0);  //game over score colour

	glTranslated(400, 800, 0);  //main screen score
	glLineWidth(5);
	glScaled(.5, .5, 0);
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (int)'S');
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (int)'c');
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (int)'o');
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (int)'r');
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (int)'e');
	glColor3f(1.0, 0.0, 0.0);
	glScaled(1.0,1.0, 0);
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (int)':');
	glColor3f(1.0, 0.0, 0.0);
	glScaled(1.0, 1.0, 0);
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (int)i + 48);
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (int)j + 48);
	glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (int)k + 48);
	glPopMatrix();
	glPopMatrix();
}


void car(float a, float b)
{
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, _textureId3);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glBegin(GL_QUADS);
    
	glColor3f(1, 1, 1);
	glTexCoord2i(0, 0);
	glVertex2f(-95 + a, 50 + b);
	glTexCoord2i(0, 1);
	glVertex2f(-95 + a, 100 + b); //back side wheel
	glTexCoord2i(1, 1);
	glVertex2f(95 + a, 100 + b);
	glTexCoord2i(1, 0);
	glVertex2f(95 + a, 50 + b);

	glEnd();
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, _textureId3);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glBegin(GL_QUADS);
	glColor3f(1, 1, 1);
	glTexCoord2i(0, 0);
	glVertex2f(-95 + a, 150 + b);
	glTexCoord2i(0, 1);
	glVertex2f(-95 + a, 200 + b);//front side wheel
	glTexCoord2i(1, 1);
	glVertex2f(95 + a, 200 + b);
	glTexCoord2i(1, 0);
	glVertex2f(95 + a, 150 + b);
	glEnd();
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, _textureId2);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glBegin(GL_QUADS);
	glColor3f(1, 1, 1);
	glTexCoord2i(0, 0);
	glVertex2f(-45 + a, 40 + b);
	glTexCoord2i(0, 1);
	glVertex2f(-45 + a, 230 + b);// middle part
	glTexCoord2i(1, 1);
	glVertex2f(45 + a, 230 + b);
	glTexCoord2i(1, 0);
	glVertex2f(45 + a, 40 + b);
	glEnd();
}

void display()
{
	int i, t;
	time++;
	if (exit1 == 0)
	{
		if (score<25)
		{
			y1-=.5;    //enemy speed control
			y2-=.5;
			y3-=.5;
		}
		if (score >= 25 && score<50)
		{
			y1 -= 0.7;
			y2 -= 0.7;
			y3 -= 0.7;
		}
		if (score >= 50)
		{
			y1 -= 2;
			y2 -= 2;
			y3 -= 2;
		}
		//
		if (y1<-250)
		{
			score += 5;
			y1 = 1000;
		}
		if (y2<-250)
		{
			score += 5;
			y2 = 1500;
		}
		if (y3<-250)
		{
			score += 5;
			y3 = 2000;
		}
		                                // collision part
		if (x<-200 || x>200)exit1 = 1;

		if (95 + x>-80 && -95 + x<80)
			if (250 + y>100 + y1 && 250 + y1>40 + y)
				exit1 = 1;

		if (95 + x>-260 && -95 + x<-140)
			if (250 + y>100 + y3 && 250 + y3>40 + y)
				exit1 = 1;

		if (95 + x>140 && -95 + x<260)
			if (250 + y>100 + y2 && 250 + y2>40 + y)
				exit1 = 1;
		
		// for drawing

		glClear(GL_COLOR_BUFFER_BIT);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();

		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, _textureId1);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		glColor3f(1.0, 1.0, 1.0);

		glBegin(GL_QUADS); //left side water

		glTexCoord2i(0, 0);
		glVertex2i(-300, 0); 
		glTexCoord2i(0, 1);
		glVertex2i(-300, 2000); 
		glTexCoord2i(1, 1);
		glVertex2i(-2000, 2000); 
		glTexCoord2i(1, 0);
		glVertex2i(-2000, 0);
		glEnd();

		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, _textureId);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glColor3f(1.0, 1.0, 1.0);
		glBegin(GL_POLYGON);
		glTexCoord2i(0, 0);           //road
		glVertex2f(-300, 0);
		glTexCoord2i(0, 1);
		glVertex2f(-300, 2000);
		glTexCoord2i(1, 1);
		glVertex2f(300, 2000);
		glTexCoord2i(1, 0);
		glVertex2f(300, 0);
		glEnd();


		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, _textureId1);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glColor3f(1.0, 1.0, 1.0);
		glBegin(GL_POLYGON);
		glTexCoord2i(0, 0);           //right side water
		glVertex2f(300, 0);
		glTexCoord2i(0, 1);
		glVertex2f(300, 2000);
		glTexCoord2i(1, 1);
		glVertex2f(2000, 2000);
		glTexCoord2i(1, 0);
		glVertex2f(2000, 0);
		glEnd();

		//glColor3f(1.0, 1.0, 1.0);
		t = 0;
		glPushMatrix();
		glColor3f(1.0,0,0);
		sc(score);
		glPopMatrix();
		car(x, y);
		enemy(x1, y1);
		enemy(x2, y2);
		enemy(x3, y3);
		glutSwapBuffers();
	}
                                  	//game over part
	else
	{
		glLineWidth(5);
		glClear(GL_COLOR_BUFFER_BIT);
		glPushMatrix();
		glTranslated(-600, -200, 0);
		sc(score);
		glPopMatrix();


		glPushMatrix();
		glColor3f(0, 0, 0); 
		glTranslated(-200, 800, 0);
		glScaled(.5, .5, 0);
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (int)'G');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (int)'A');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (int)'M');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (int)'E');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (int)'O');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (int)'V');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (int)'E');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (int)'R');
		glPopMatrix();

		glutSwapBuffers();
	}
}


void myInit(void) {

	glClearColor(1.0, 1.0, 1.0, 1.0);
	glMatrixMode(GL_PROJECTION);
	Image* image = loadBMP("road.bmp");
	Image* image1 = loadBMP("sea.bmp");
	Image* image2 = loadBMP("car.bmp");
	Image* image3 = loadBMP("wheel.bmp");
	Image* image4 = loadBMP("ememy car.bmp");
	Image* image5 = loadBMP("enemy wheel.bmp");

	_textureId = loadTexture(image);
	_textureId1 = loadTexture(image1);
	_textureId2 = loadTexture(image2);
	_textureId3 = loadTexture(image3);
	_textureId4 = loadTexture(image4);
	_textureId5 = loadTexture(image5);
	delete image;
	delete image1;
	delete image2;
	delete image3;
	delete image4;
	delete image5;
}
void keyboards(unsigned char keys, int x4, int y4)
{
	//to quit
	if (keys == 27)
	{
		exit(-1);
	}


	//to start
	if (keys == (char)13)
	{
		glutIdleFunc(display);
	}


	//track color
	if (keys == '1')
	{
		glClearColor(1.0, 0.0, 0.0, 0.0);
	}

	if (keys == '3')
	{
		glClearColor(0.0, 0.0, 1.0, 0.0);
	}

	if (keys == '0')
	{

		glClearColor(1.0, 1.0, 1.0, 1.0);
	}



	//movement keys
	if (keys == 'a')
		x -= 20;
	if (keys == 'd')
		x += 20;
	if (keys == 'w')
		y += 20;
	if (keys == 's')
		y -= 20;
	glutPostRedisplay();

}



void main(int argc, char **argv)
{
	glutInit(&argc, argv);

	glutInitWindowSize(2000, 2000);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
	glutCreateWindow("Car Race");
	glClearColor(1, 1, 1, 1);//set Background
	glutDisplayFunc(display);
	glutKeyboardFunc(keyboards);
	myInit();
	//createline();
	gluOrtho2D(-1000, 1000, 0, 1000);
	glutMainLoop();
}
