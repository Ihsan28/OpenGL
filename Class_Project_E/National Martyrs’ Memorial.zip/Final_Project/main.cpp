#include<cstdio>
#include <windows.h>
#include<math.h>
# define PI 3.14159265358979323846
#include <GL/gl.h>
#include <GL/glut.h>
GLfloat q=0.0f;
GLfloat position = 0.0f;
GLfloat speed = 0.01f;
GLfloat position1 = 0.0f;
GLfloat speed1 = 0.01f;
int i;
GLfloat twicePi = 2.0f * PI;
int triangleAmount = 50;

void Idle()
{
    glutPostRedisplay();/// marks the current window as needing to be redisplayed
}

void night()
{
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT);

	///Sky
	glBegin(GL_QUADS);
	glColor3ub(115, 115, 115);
	glVertex2f(-1.0f, -1.0f);
	glVertex2f(1.0f, -1.0f);
    glVertex2f(1.0f, 1.0f);
	glVertex2f(-1.0f, 1.0f);
    glEnd();
    glLoadIdentity();
    ///-------------------------
    ///Moon
	GLfloat a5=.25f; GLfloat b5=0.8f; GLfloat radius5 =.12f;
	triangleAmount = 20;
	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 255);                  ///Moon
	//glVertex2f(x, y);
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
			    a5 + (radius5 * cos(i *  twicePi / triangleAmount)),
			    b5 + (radius5* sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	glLoadIdentity();
	///-----------------------

    ///Clouds
     glPushMatrix();
    glTranslatef(position,0.0f, 0.0f);

    ///Cloud1
	GLfloat x=.5f; GLfloat y=.8f; GLfloat radius =.05f;
	//GLfloat twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	    glColor3ub(230, 255, 255);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	GLfloat a=.55f; GLfloat b=.78f;

	glBegin(GL_TRIANGLE_FAN);
	    glColor3ub(230, 255, 255);
		glVertex2f(a, b); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            a + (radius * cos(i *  twicePi / triangleAmount)),
			    b + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	GLfloat c=.45f; GLfloat d=.78f;

	glBegin(GL_TRIANGLE_FAN);
	    glColor3ub(230, 255, 255);
		glVertex2f(c, d); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            c + (radius * cos(i *  twicePi / triangleAmount)),
			    d + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	GLfloat e=.52f; GLfloat f=.75f;

	glBegin(GL_TRIANGLE_FAN);
	    glColor3ub(230, 255, 255);
		glVertex2f(e, f); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            e + (radius * cos(i *  twicePi / triangleAmount)),
			    f+ (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	GLfloat g=.6f; GLfloat h=.77f;

	glBegin(GL_TRIANGLE_FAN);
	    glColor3ub(230, 255, 255);
		glVertex2f(g, h); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            g + (radius * cos(i *  twicePi / triangleAmount)),
			    h+ (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	glPopMatrix();
	glLoadIdentity();

	///Cloud2
	glPushMatrix();
    glTranslatef(position1,0.0f, 0.0f);
	GLfloat x1=-.5f; GLfloat y1=.8f;
	//int triangleAmount = 20;
	//GLfloat twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	    glColor3ub(230, 255, 255);
		glVertex2f(x1, y1); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x1 + (radius * cos(i *  twicePi / triangleAmount)),
			    y1 + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	GLfloat a2 =-.55f;

	glBegin(GL_TRIANGLE_FAN);
	    glColor3ub(230, 255, 255);
		glVertex2f(a2, b); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            a2 + (radius * cos(i *  twicePi / triangleAmount)),
			    b + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	GLfloat c1=-.45f;

	glBegin(GL_TRIANGLE_FAN);
	    glColor3ub(230, 255, 255);
		glVertex2f(c1, d); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            c1 + (radius * cos(i *  twicePi / triangleAmount)),
			    d + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	GLfloat e1=-.52f;

	glBegin(GL_TRIANGLE_FAN);
	    glColor3ub(230, 255, 255);
		glVertex2f(e1, f); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            e1 + (radius * cos(i *  twicePi / triangleAmount)),
			    f+ (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	GLfloat g1=-.6f;

	glBegin(GL_TRIANGLE_FAN);
	    glColor3ub(230, 255, 255);
		glVertex2f(g1, h); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            g1 + (radius * cos(i *  twicePi / triangleAmount)),
			    h+ (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	glPopMatrix();

	glLoadIdentity();
	///----------------------------------

	///MainStructure

	 glBegin(GL_TRIANGLES);   ///top
	glColor3ub(166, 166, 166);
	glVertex2f(-0.01f, 0.7f);
    glVertex2f(0.01f, 0.7f);
    glVertex2f(0.0f, 0.75f);
	glEnd();
	//main base
	glBegin(GL_TRIANGLES);   /// Middle
	glColor3ub(179, 179, 179);
	glVertex2f(-0.2f, -0.1f);
    glVertex2f(0.2f, -0.1f);
    glVertex2f(0.0f, 0.7f);
	glEnd();

	glBegin(GL_TRIANGLES);  ///LOwerMiddle
	glColor3ub(150,40,27);
	glVertex2f(-0.2f, -0.1f);
    glVertex2f(0.2f, -0.1f);
    glVertex2f(0.0f, 0.0f);
	glEnd();

    glBegin(GL_QUADS);      ///Central Middle
    glColor3ub(128, 128, 128);
	glVertex2f(0.0f,0.0f);
    glVertex2f(0.125f, 0.2);
    glVertex2f(0.0f, 0.4f);
    glVertex2f(-0.125f, 0.2f);
	glEnd();

	glBegin(GL_POLYGON);     ///Central Middle IN
	glColor3ub(166, 166, 166);
	glVertex2f(-0.115f,0.215f);
	glVertex2f(-0.125f, 0.2f);
    glVertex2f(-0.115f, 0.185);
    glVertex2f(0.115f,0.185f);
    glVertex2f(0.125f, 0.2);
    glVertex2f(0.115f, 0.215f);
	glEnd();

	//main base border
	glBegin(GL_QUADS);     ///border
	glColor3ub(230, 230, 230);
	glVertex2f(0.2f,-0.1f);
    glVertex2f(0.21f, -0.1f);
    glVertex2f(0.01f,0.7f);
    glVertex2f(0.00f, 0.7f);
	glEnd();

	glBegin(GL_QUADS);     ///border
	glColor3ub(230, 230, 230);
	glVertex2f(-0.2f,-0.1f);
    glVertex2f(-0.21f, -0.1f);
    glVertex2f(-0.01f,0.7f);
    glVertex2f(-0.00f, 0.7f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(179, 179, 179);
	glVertex2f(0.21f, -0.1f);
    glVertex2f(0.3f, -0.1f);
    glVertex2f(0.06f, 0.5f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(179, 179, 179);
	glVertex2f(-0.21f, -0.1f);
    glVertex2f(-0.3f, -0.1f);
    glVertex2f(-0.06f, 0.5f);
	glEnd();

	glBegin(GL_QUADS);         ///border
	glColor3ub(230, 230, 230);
	glVertex2f(0.3f,-0.1f);
    glVertex2f(0.31f, -0.1f);
    glVertex2f(0.055f,0.52f);
    glVertex2f(0.054f, 0.5f);
	glEnd();

	glBegin(GL_QUADS);              ///border
	glColor3ub(230, 230, 230);
	glVertex2f(-0.3f,-0.1f);
    glVertex2f(-0.31f, -0.1f);
    glVertex2f(-0.055f,0.52f);
    glVertex2f(-0.054f, 0.5f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(179, 179, 179);
	glVertex2f(0.31f, -0.1f);
    glVertex2f(0.4f, -0.1f);
    glVertex2f(0.1f, 0.4f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(179, 179, 179);
	glVertex2f(-0.31f, -0.1f);
    glVertex2f(-0.4f, -0.1f);
    glVertex2f(-0.1f, 0.4f);
	glEnd();

	glBegin(GL_QUADS);                 ///border
	glColor3ub(230, 230, 230);
	glVertex2f(0.4f,-0.1f);
    glVertex2f(0.41f, -0.1f);
    glVertex2f(0.095f,0.42f);
    glVertex2f(0.1f, 0.4f);
	glEnd();

	glBegin(GL_QUADS);                    ///border
	glColor3ub(230, 230, 230);
	glVertex2f(-0.4f,-0.1f);
    glVertex2f(-0.41f, -0.1f);
    glVertex2f(-0.095f,0.42f);
    glVertex2f(-0.1f, 0.4f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(179, 179, 179);
	glVertex2f(0.41f, -0.1f);
    glVertex2f(0.5f, -0.1f);
    glVertex2f(0.167f, 0.3f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(179, 179, 179);
	glVertex2f(-0.41f, -0.1f);
    glVertex2f(-0.5f, -0.1f);
    glVertex2f(-0.167f, 0.3f);
	glEnd();

	glBegin(GL_QUADS);                  ///border
	glColor3ub(230, 230, 230);
	glVertex2f(0.5f,-0.1f);
    glVertex2f(0.51f, -0.1f);
    glVertex2f(0.1568f,0.316f);
    glVertex2f(0.16f, 0.3f);
	glEnd();

	glBegin(GL_QUADS);                  ///border
	glColor3ub(230, 230, 230);
	glVertex2f(-0.5f,-0.1f);
    glVertex2f(-0.51f, -0.1f);
    glVertex2f(-0.1568f,0.316f);
    glVertex2f(-0.16f, 0.3f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(179, 179, 179);
	glVertex2f(0.51f, -0.1f);
    glVertex2f(0.6f, -0.1f);
    glVertex2f(0.17f, 0.3f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(179, 179, 179);
	glVertex2f(-0.51f, -0.1f);
    glVertex2f(-0.6f, -0.1f);
    glVertex2f(-0.17f, 0.3f);
	glEnd();

	glBegin(GL_QUADS);                    ///border
	glColor3ub(230, 230, 230);
	glVertex2f(0.6f,-0.1f);
    glVertex2f(0.615f, -0.1f);
    glVertex2f(0.15f,0.33f);
    glVertex2f(0.167f, 0.3f);
	glEnd();

	glBegin(GL_QUADS);                ///border
	glColor3ub(230, 230, 230);
	glVertex2f(-0.6f,-0.1f);
    glVertex2f(-0.615f, -0.1f);
    glVertex2f(-0.15f,0.33f);
    glVertex2f(-0.167f, 0.3f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(179, 179, 179);
	glVertex2f(0.61f, -0.1f);
    glVertex2f(0.7f, -0.1f);
    glVertex2f(0.29f, 0.2f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(179, 179, 179);
	glVertex2f(-0.61f, -0.1f);
    glVertex2f(-0.7f, -0.1f);
    glVertex2f(-0.29f, 0.2f);
	glEnd();

	glBegin(GL_QUADS);               ///border
	glColor3ub(230, 230, 230);
	glVertex2f(0.7f,-0.1f);
    glVertex2f(0.718f, -0.1f);
    glVertex2f(0.25f,0.24f);
    glVertex2f(0.275f, 0.21f);
	glEnd();

	glBegin(GL_QUADS);              ///border
	glColor3ub(230, 230, 230);
	glVertex2f(-0.7f,-0.1f);
    glVertex2f(-0.718f, -0.1f);
    glVertex2f(-0.25f,0.24f);
    glVertex2f(-0.275f, 0.21f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(179, 179, 179);
	glVertex2f(0.71f, -0.1f);
    glVertex2f(0.8f, -0.1f);
    glVertex2f(0.3f, 0.2f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(179, 179, 179);
	glVertex2f(-0.71f, -0.1f);
    glVertex2f(-0.8f, -0.1f);
    glVertex2f(-0.3f, 0.2f);
	glEnd();

	glBegin(GL_QUADS);                 ///border
	glColor3ub(230, 230, 230);
	glVertex2f(0.8f,-0.1f);
    glVertex2f(0.82f, -0.1f);
    glVertex2f(0.25f,0.241f);
    glVertex2f(0.265f, 0.221f);
	glEnd();

	glBegin(GL_QUADS);               ///border
	glColor3ub(230, 230, 230);
	glVertex2f(-0.8f,-0.1f);
    glVertex2f(-0.82f, -0.1f);
    glVertex2f(-0.25f,0.241f);
    glVertex2f(-0.265f, 0.221f);
	glEnd();
	glLoadIdentity();
	///----------------------------------------------------
	///Stairs
    glBegin(GL_QUADS);
	glColor3ub(150,40,27);
	glVertex2f(-1.0f, -0.1f);
	glVertex2f(-1.0f, -.3f);
	glVertex2f(1.0f, -.3f);
	glVertex2f(1.0f, -.1f);
    glEnd();

    glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(-1.0f, -0.133f);
	glVertex2f(1.0f, -.133f);

	glColor3ub(0,0,0);
	glVertex2f(-1.0f, -0.166f);
	glVertex2f(1.0f, -.166f);

	glColor3ub(0,0,0);
	glVertex2f(-1.0f, -0.2f);
	glVertex2f(1.0f, -.2f);

	glColor3ub(0,0,0);
	glVertex2f(-1.0f, -0.233f);
	glVertex2f(1.0f, -.233f);

	glColor3ub(0,0,0);
	glVertex2f(-1.0f, -0.266f);
	glVertex2f(1.0f, -.266f);

	glColor3ub(0,0,0);
	glVertex2f(-1.0f, -0.3f);
	glVertex2f(1.0f, -.3f);

	glColor3ub(0,0,0);
	glVertex2f(-1.0f, -0.1f);
	glVertex2f(1.0f, -.1f);
    glEnd();
    glLoadIdentity();
    ///-------------------------------------------
    ///Water
    glBegin(GL_QUADS);           ///(-0.5 -> 0.5)
	glColor3ub(102, 0, 0);
	glVertex2f(-0.5f, -1.0f);
	glVertex2f(0.5f, -1.0f);
    glVertex2f(0.4f, -0.3f);
    glVertex2f(-0.4f, -0.3f);
    glEnd();

    glBegin(GL_QUADS);                        ///Main Water
	glColor3ub(0, 153, 204);
	glVertex2f(-0.4f, -1.0f);
	glVertex2f(0.4f, -1.0f);
    glVertex2f(0.3f, -0.4f);
    glVertex2f(-0.3f, -0.4f);
    glEnd();
    glLoadIdentity();
    ///-------------------------------------


    ///Flag
    glBegin(GL_QUADS);
	glColor3ub(242, 242, 242);
	glVertex2f(-0.01f, -1.0f);
	glVertex2f(0.01f, -1.0f);
    glVertex2f(0.01f, 0.05f);
    glVertex2f(-0.01f, 0.05f);
    glEnd();

    glBegin(GL_QUADS);
	glColor3ub(0, 153, 51);
	glVertex2f(0.01f, 0.05f);
	glVertex2f(0.37f, 0.05f);
    glVertex2f(0.37f, -0.2f);
    glVertex2f(0.01f, -0.2f);
    glEnd();
     // int i;

	GLfloat a1=.17f; GLfloat b1=-0.07f; GLfloat radius1 =.07f;
	triangleAmount = 20;
	//GLfloat twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	    glColor3ub(255, 0, 0);
		glVertex2f(a1, b1); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            a1 + (radius1 * cos(i *  twicePi / triangleAmount)),
			    b1 + (radius1 * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	///----------------------------------------------

	///Yard
	glBegin(GL_QUADS);                   ///Left Yard
	glColor3ub(51, 102, 0);
	glVertex2f(-1.0f, -0.3f);
	glVertex2f(-1.0f, -1.0f);
    glVertex2f(-0.5f, -1.0f);
    glVertex2f(-0.4f, -0.3f);
    glEnd();

    glBegin(GL_QUADS);            ///Right Yard
	glColor3ub(51, 102, 0);
	glVertex2f(1.0f, -0.3f);
	glVertex2f(1.0f, -1.0f);
    glVertex2f(0.5f, -1.0f);
    glVertex2f(0.4f, -0.3f);
    glEnd();
    ///-------------------------------------------------

    ///Light
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);        ///Left1 -> (-0.7 -> -0.68)
	glVertex2f(-0.7f, -1.0f);
	glVertex2f(-0.68f, -1.0f);
    glVertex2f(-0.68f, -0.7f);
    glVertex2f(-0.7f, -0.7f);
    glColor3ub(255, 255, 255);        ///Left1_up -> (-0.3 -> -0.2)
	glVertex2f(-0.7f, -0.7f);
	glVertex2f(-0.68f, -0.7f);
    glVertex2f(-0.6f, -0.67f);
    glVertex2f(-0.615f, -0.665f);
    glColor3ub(255, 255, 160);        ///Left1_Light -> (-0.3 -> -0.2)
	glVertex2f(-0.66f, -1.0f);
	glVertex2f(-0.5f, -1.0f);
	glVertex2f(-0.6f, -0.665f);
    glVertex2f(-0.66f, -0.685f);

    glColor3ub(255, 255, 255);        ///Right1 -> (-0.3 -> -0.2)
	glVertex2f(0.68f, -1.0f);
	glVertex2f(0.7f, -1.0f);
    glVertex2f(0.7f, -0.7f);
    glVertex2f(0.68f, -0.7f);
    glColor3ub(255, 255, 255);        ///Right1_up -> (-0.3 -> -0.2)
	glVertex2f(0.68f, -0.7f);
	glVertex2f(0.7f, -0.7f);
	glVertex2f(0.615f, -0.665f);
    glVertex2f(0.6f, -0.67f);
    glColor3ub(255, 255, 160);        ///Right1_Light -> (-0.3 -> -0.2)
	glVertex2f(0.5f, -1.0f);
	glVertex2f(0.66f, -1.0f);
	glVertex2f(0.66f, -0.685f);
	glVertex2f(0.6f, -0.665f);


    glColor3ub(255, 255, 255);        ///Right2 -> (-0.3 -> -0.2)
	glVertex2f(0.585f, -0.7f);
	glVertex2f(0.6f, -0.7f);
    glVertex2f(0.6f, -0.28f);
    glVertex2f(0.585f, -0.28f);
    glColor3ub(255, 255, 255);        ///Right2_up -> (-0.3 -> -0.2)
	glVertex2f(0.585f, -0.28f);
	glVertex2f(0.6f, -0.28f);
    glVertex2f(0.55f, -0.26f);
    glVertex2f(0.535f, -0.26f);
	glColor3ub(255, 255, 180);        ///Right2_Light -> (-0.3 -> -0.2)
	glVertex2f(0.46f, -0.7f);
	glVertex2f(0.565f, -0.7f);
	glVertex2f(0.565f, -0.273f);
	glVertex2f(0.538f, -0.26f);

    glColor3ub(255, 255, 255);        ///Left2 -> (-0.6 -> -0.585)
	glVertex2f(-0.6f, -0.7f);
	glVertex2f(-0.585f, -0.7f);
	glVertex2f(-0.585f, -0.28f);
    glVertex2f(-0.6f, -0.28f);
    glColor3ub(255, 255, 255);        ///Left2_up -> (-0.3 -> -0.2)
	glVertex2f(-0.6f, -0.28f);
	glVertex2f(-0.585f, -0.28f);
    glVertex2f(-0.535f, -0.26f);
    glVertex2f(-0.55f, -0.26f);
    glColor3ub(255, 255, 180);        ///Left2_Light -> (-0.3 -> -0.2)
	glVertex2f(-0.565f, -0.7f);
	glVertex2f(-0.46f, -0.7f);
	glVertex2f(-0.538f, -0.26f);
    glVertex2f(-0.565f, -0.273f);

    glEnd();
    ///------------------------------------------

    glFlush();
}
///-------------------------------------------------------------------------


void night_demo(int a)
{
    glutDisplayFunc(night);
}
///----------------------------------------------------------------------------------------------------------------------------


void day()                    /// Day View--------------------------------------
{
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT);

	///Sky
	glBegin(GL_QUADS);
	glColor3ub(38, 154, 214);
	glVertex2f(-1.0f, -1.0f);
	glVertex2f(1.0f, -1.0f);
    glVertex2f(1.0f, 1.0f);
	glVertex2f(-1.0f, 1.0f);
    glEnd();
    glLoadIdentity();
    ///-------------------------
    ///Sun
    GLfloat a4=.25f; GLfloat b4=0.8f; GLfloat radius4 =.1f;
    glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 26);                  ///Sun
	//glVertex2f(x, y);
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
			    a4 + (radius4 * cos(i *  twicePi / triangleAmount)),
			    b4 + (radius4* sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	glLoadIdentity();
    ///--------------------------------------
    ///Clouds
     glPushMatrix();
    glTranslatef(position,0.0f, 0.0f);

    ///Cloud1
	GLfloat x=.5f; GLfloat y=.8f; GLfloat radius =.05f;
	triangleAmount = 20;

	glBegin(GL_TRIANGLE_FAN);
	    glColor3ub(230, 255, 255);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	GLfloat a=.55f; GLfloat b=.78f;

	glBegin(GL_TRIANGLE_FAN);
	    glColor3ub(230, 255, 255);
		glVertex2f(a, b); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            a + (radius * cos(i *  twicePi / triangleAmount)),
			    b + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	GLfloat c=.45f; GLfloat d=.78f;

	glBegin(GL_TRIANGLE_FAN);
	    glColor3ub(230, 255, 255);
		glVertex2f(c, d); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            c + (radius * cos(i *  twicePi / triangleAmount)),
			    d + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	GLfloat e=.52f; GLfloat f=.75f;

	glBegin(GL_TRIANGLE_FAN);
	    glColor3ub(230, 255, 255);
		glVertex2f(e, f); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            e + (radius * cos(i *  twicePi / triangleAmount)),
			    f+ (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	GLfloat g=.6f; GLfloat h=.77f;

	glBegin(GL_TRIANGLE_FAN);
	    glColor3ub(230, 255, 255);
		glVertex2f(g, h); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            g + (radius * cos(i *  twicePi / triangleAmount)),
			    h+ (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	glPopMatrix();
	glLoadIdentity();


	///Cloud2
	glPushMatrix();
    glTranslatef(position1,0.0f, 0.0f);
	GLfloat x1=-.5f; GLfloat y1=.8f;
	//int triangleAmount = 20;
	//GLfloat twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	    glColor3ub(230, 255, 255);
		glVertex2f(x1, y1); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x1 + (radius * cos(i *  twicePi / triangleAmount)),
			    y1 + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	GLfloat a2 =-.55f;

	glBegin(GL_TRIANGLE_FAN);
	    glColor3ub(230, 255, 255);
		glVertex2f(a2, b); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            a2 + (radius * cos(i *  twicePi / triangleAmount)),
			    b + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	GLfloat c1=-.45f;

	glBegin(GL_TRIANGLE_FAN);
	    glColor3ub(230, 255, 255);
		glVertex2f(c1, d); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            c1 + (radius * cos(i *  twicePi / triangleAmount)),
			    d + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	GLfloat e1=-.52f;

	glBegin(GL_TRIANGLE_FAN);
	    glColor3ub(230, 255, 255);
		glVertex2f(e1, f); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            e1 + (radius * cos(i *  twicePi / triangleAmount)),
			    f+ (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();

	GLfloat g1=-.6f;

	glBegin(GL_TRIANGLE_FAN);
	    glColor3ub(230, 255, 255);
		glVertex2f(g1, h); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            g1 + (radius * cos(i *  twicePi / triangleAmount)),
			    h+ (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	glPopMatrix();

	glLoadIdentity();
	///----------------------------------
	///MainStructure

	 glBegin(GL_TRIANGLES);
	glColor3ub(166, 166, 166);
	glVertex2f(-0.01f, 0.7f);
    glVertex2f(0.01f, 0.7f);
    glVertex2f(0.0f, 0.75f);
	glEnd();
	//main base
	glBegin(GL_TRIANGLES);
	glColor3ub(204, 204, 204);
	glVertex2f(-0.2f, -0.1f);
    glVertex2f(0.2f, -0.1f);
    glVertex2f(0.0f, 0.7f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(150,40,27);
	glVertex2f(-0.2f, -0.1f);
    glVertex2f(0.2f, -0.1f);
    glVertex2f(0.0f, 0.0f);
	glEnd();

    glBegin(GL_QUADS);
    glColor3ub(128, 128, 128);
	glVertex2f(0.0f,0.0f);
    glVertex2f(0.125f, 0.2);
    glVertex2f(0.0f, 0.4f);
    glVertex2f(-0.125f, 0.2f);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(166, 166, 166);
	glVertex2f(-0.115f,0.215f);
	glVertex2f(-0.125f, 0.2f);
    glVertex2f(-0.115f, 0.185);
    glVertex2f(0.115f,0.185f);
    glVertex2f(0.125f, 0.2);
    glVertex2f(0.115f, 0.215f);
	glEnd();

	//main base border
	glBegin(GL_QUADS);
	glColor3ub(230, 230, 230);
	glVertex2f(0.2f,-0.1f);
    glVertex2f(0.21f, -0.1f);
    glVertex2f(0.01f,0.7f);
    glVertex2f(0.00f, 0.7f);
	glEnd();

	glBegin(GL_QUADS);
	glColor3ub(230, 230, 230);
	glVertex2f(-0.2f,-0.1f);
    glVertex2f(-0.21f, -0.1f);
    glVertex2f(-0.01f,0.7f);
    glVertex2f(-0.00f, 0.7f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(204, 204, 204);
	glVertex2f(0.21f, -0.1f);
    glVertex2f(0.3f, -0.1f);
    glVertex2f(0.06f, 0.5f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(204, 204, 204);
	glVertex2f(-0.21f, -0.1f);
    glVertex2f(-0.3f, -0.1f);
    glVertex2f(-0.06f, 0.5f);
	glEnd();

	glBegin(GL_QUADS);
	glColor3ub(230, 230, 230);
	glVertex2f(0.3f,-0.1f);
    glVertex2f(0.31f, -0.1f);
    glVertex2f(0.055f,0.52f);
    glVertex2f(0.054f, 0.5f);
	glEnd();

	glBegin(GL_QUADS);
	glColor3ub(230, 230, 230);
	glVertex2f(-0.3f,-0.1f);
    glVertex2f(-0.31f, -0.1f);
    glVertex2f(-0.055f,0.52f);
    glVertex2f(-0.054f, 0.5f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(204, 204, 204);
	glVertex2f(0.31f, -0.1f);
    glVertex2f(0.4f, -0.1f);
    glVertex2f(0.1f, 0.4f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(204, 204, 204);
	glVertex2f(-0.31f, -0.1f);
    glVertex2f(-0.4f, -0.1f);
    glVertex2f(-0.1f, 0.4f);
	glEnd();

	glBegin(GL_QUADS);
	glColor3ub(230, 230, 230);
	glVertex2f(0.4f,-0.1f);
    glVertex2f(0.41f, -0.1f);
    glVertex2f(0.095f,0.42f);
    glVertex2f(0.1f, 0.4f);
	glEnd();

	glBegin(GL_QUADS);
	glColor3ub(230, 230, 230);
	glVertex2f(-0.4f,-0.1f);
    glVertex2f(-0.41f, -0.1f);
    glVertex2f(-0.095f,0.42f);
    glVertex2f(-0.1f, 0.4f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(204, 204, 204);
	glVertex2f(0.41f, -0.1f);
    glVertex2f(0.5f, -0.1f);
    glVertex2f(0.167f, 0.3f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(204, 204, 204);
	glVertex2f(-0.41f, -0.1f);
    glVertex2f(-0.5f, -0.1f);
    glVertex2f(-0.167f, 0.3f);
	glEnd();

	glBegin(GL_QUADS);
	glColor3ub(230, 230, 230);
	glVertex2f(0.5f,-0.1f);
    glVertex2f(0.51f, -0.1f);
    glVertex2f(0.1568f,0.316f);
    glVertex2f(0.16f, 0.3f);
	glEnd();

	glBegin(GL_QUADS);
	glColor3ub(230, 230, 230);
	glVertex2f(-0.5f,-0.1f);
    glVertex2f(-0.51f, -0.1f);
    glVertex2f(-0.1568f,0.316f);
    glVertex2f(-0.16f, 0.3f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(204, 204, 204);
	glVertex2f(0.51f, -0.1f);
    glVertex2f(0.6f, -0.1f);
    glVertex2f(0.17f, 0.3f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(204, 204, 204);
	glVertex2f(-0.51f, -0.1f);
    glVertex2f(-0.6f, -0.1f);
    glVertex2f(-0.17f, 0.3f);
	glEnd();

	glBegin(GL_QUADS);
	glColor3ub(230, 230, 230);
	glVertex2f(0.6f,-0.1f);
    glVertex2f(0.615f, -0.1f);
    glVertex2f(0.15f,0.33f);
    glVertex2f(0.167f, 0.3f);
	glEnd();

	glBegin(GL_QUADS);
	glColor3ub(230, 230, 230);
	glVertex2f(-0.6f,-0.1f);
    glVertex2f(-0.615f, -0.1f);
    glVertex2f(-0.15f,0.33f);
    glVertex2f(-0.167f, 0.3f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(204, 204, 204);
	glVertex2f(0.61f, -0.1f);
    glVertex2f(0.7f, -0.1f);
    glVertex2f(0.29f, 0.2f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(204, 204, 204);
	glVertex2f(-0.61f, -0.1f);
    glVertex2f(-0.7f, -0.1f);
    glVertex2f(-0.29f, 0.2f);
	glEnd();

	glBegin(GL_QUADS);
	glColor3ub(230, 230, 230);
	glVertex2f(0.7f,-0.1f);
    glVertex2f(0.718f, -0.1f);
    glVertex2f(0.25f,0.24f);
    glVertex2f(0.275f, 0.21f);
	glEnd();

	glBegin(GL_QUADS);
	glColor3ub(230, 230, 230);
	glVertex2f(-0.7f,-0.1f);
    glVertex2f(-0.718f, -0.1f);
    glVertex2f(-0.25f,0.24f);
    glVertex2f(-0.275f, 0.21f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(204, 204, 204);
	glVertex2f(0.71f, -0.1f);
    glVertex2f(0.8f, -0.1f);
    glVertex2f(0.3f, 0.2f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(204, 204, 204);
	glVertex2f(-0.71f, -0.1f);
    glVertex2f(-0.8f, -0.1f);
    glVertex2f(-0.3f, 0.2f);
	glEnd();

	glBegin(GL_QUADS);
	glColor3ub(230, 230, 230);
	glVertex2f(0.8f,-0.1f);
    glVertex2f(0.82f, -0.1f);
    glVertex2f(0.25f,0.241f);
    glVertex2f(0.265f, 0.221f);
	glEnd();

	glBegin(GL_QUADS);
	glColor3ub(230, 230, 230);
	glVertex2f(-0.8f,-0.1f);
    glVertex2f(-0.82f, -0.1f);
    glVertex2f(-0.25f,0.241f);
    glVertex2f(-0.265f, 0.221f);
	glEnd();
	glLoadIdentity();
	///----------------------------------------------------
	///Stairs
	 glBegin(GL_QUADS);
	glColor3ub(150,40,27);
	glVertex2f(-1.0f, -0.1f);
	glVertex2f(-1.0f, -.3f);
	glVertex2f(1.0f, -.3f);
	glVertex2f(1.0f, -.1f);
    glEnd();

    glBegin(GL_LINES);
	glColor3ub(0,0,0);
	glVertex2f(-1.0f, -0.133f);
	glVertex2f(1.0f, -.133f);

	glColor3ub(0,0,0);
	glVertex2f(-1.0f, -0.166f);
	glVertex2f(1.0f, -.166f);

	glColor3ub(0,0,0);
	glVertex2f(-1.0f, -0.2f);
	glVertex2f(1.0f, -.2f);

	glColor3ub(0,0,0);
	glVertex2f(-1.0f, -0.233f);
	glVertex2f(1.0f, -.233f);

	glColor3ub(0,0,0);
	glVertex2f(-1.0f, -0.266f);
	glVertex2f(1.0f, -.266f);

	glColor3ub(0,0,0);
	glVertex2f(-1.0f, -0.3f);
	glVertex2f(1.0f, -.3f);

	glColor3ub(0,0,0);
	glVertex2f(-1.0f, -0.1f);
	glVertex2f(1.0f, -.1f);
    glEnd();
    glLoadIdentity();
    ///-------------------------------------------
    ///Water
    glBegin(GL_QUADS);
	glColor3ub(102, 0, 0);
	glVertex2f(-0.5f, -1.0f);
	glVertex2f(0.5f, -1.0f);
    glVertex2f(0.4f, -0.3f);
    glVertex2f(-0.4f, -0.3f);
    glEnd();

    glBegin(GL_QUADS);
	glColor3ub(102, 204, 255);
	glVertex2f(-0.4f, -1.0f);
	glVertex2f(0.4f, -1.0f);
    glVertex2f(0.3f, -0.4f);
    glVertex2f(-0.3f, -0.4f);
    glEnd();
    glLoadIdentity();
    ///-------------------------------------

    ///Flag

    glBegin(GL_QUADS);
	glColor3ub(242, 242, 242);
	glVertex2f(-0.01f, -1.0f);
	glVertex2f(0.01f, -1.0f);
    glVertex2f(0.01f, 0.05f);
    glVertex2f(-0.01f, 0.05f);
    glEnd();

    glBegin(GL_QUADS);
	glColor3ub(0, 153, 51);
	glVertex2f(0.01f, 0.05f);
	glVertex2f(0.37f, 0.05f);
    glVertex2f(0.37f, -0.2f);
    glVertex2f(0.01f, -0.2f);
    glEnd();
     // int i;

	GLfloat a1=.17f; GLfloat b1=-0.07f; GLfloat radius1 =.07f;
	triangleAmount = 20;
	//GLfloat twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	    glColor3ub(255, 0, 0);
		glVertex2f(a1, b1); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            a1 + (radius1 * cos(i *  twicePi / triangleAmount)),
			    b1 + (radius1 * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	///----------------------------------------------
	///Yard
	glBegin(GL_QUADS);                 ///Left
	glColor3ub(64, 191, 64);
	glVertex2f(-1.0f, -0.3f);
	glVertex2f(-1.0f, -1.0f);
    glVertex2f(-0.5f, -1.0f);
    glVertex2f(-0.4f, -0.3f);
    glEnd();

    glBegin(GL_QUADS);               ///Right
	glColor3ub(64, 191, 64);
	glVertex2f(1.0f, -0.3f);
	glVertex2f(1.0f, -1.0f);
    glVertex2f(0.5f, -1.0f);
    glVertex2f(0.4f, -0.3f);
    glEnd();
    glLoadIdentity();

    ///Light
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);        ///Left1 -> (-0.3 -> -0.2)
	glVertex2f(-0.7f, -1.0f);
	glVertex2f(-0.68f, -1.0f);
    glVertex2f(-0.68f, -0.7f);
    glVertex2f(-0.7f, -0.7f);
    glColor3ub(255, 255, 255);        ///Left1_up -> (-0.3 -> -0.2)
	glVertex2f(-0.7f, -0.7f);
	glVertex2f(-0.68f, -0.7f);
    glVertex2f(-0.6f, -0.67f);
    glVertex2f(-0.615f, -0.665f);

    glColor3ub(255, 255, 255);        ///Right1 -> (-0.3 -> -0.2)
	glVertex2f(0.68f, -1.0f);
	glVertex2f(0.7f, -1.0f);
    glVertex2f(0.7f, -0.7f);
    glVertex2f(0.68f, -0.7f);
    glColor3ub(255, 255, 255);        ///Right1_up -> (-0.3 -> -0.2)
	glVertex2f(0.68f, -0.7f);
	glVertex2f(0.7f, -0.7f);
	glVertex2f(0.615f, -0.665f);
    glVertex2f(0.6f, -0.67f);

    glColor3ub(255, 255, 255);        ///Right2 -> (-0.3 -> -0.2)
	glVertex2f(0.585f, -0.7f);
	glVertex2f(0.6f, -0.7f);
    glVertex2f(0.6f, -0.28f);
    glVertex2f(0.585f, -0.28f);
    glColor3ub(255, 255, 255);        ///Right2_up -> (-0.3 -> -0.2)
	glVertex2f(0.585f, -0.28f);
	glVertex2f(0.6f, -0.28f);
    glVertex2f(0.55f, -0.26f);
    glVertex2f(0.535f, -0.26f);

    glColor3ub(255, 255, 255);        ///Left2 -> (-0.3 -> -0.2)
	glVertex2f(-0.6f, -0.7f);
	glVertex2f(-0.585f, -0.7f);
	glVertex2f(-0.585f, -0.28f);
    glVertex2f(-0.6f, -0.28f);
    glColor3ub(255, 255, 255);        ///Left2_up -> (-0.3 -> -0.2)
	glVertex2f(-0.6f, -0.28f);
	glVertex2f(-0.585f, -0.28f);
    glVertex2f(-0.535f, -0.26f);
    glVertex2f(-0.55f, -0.26f);

    glEnd();
    ///------------------------------------------

    glutTimerFunc(5000, night_demo, 0);


    glFlush();

}

void update(int value)
{

    if(position > 1.0)
        position = -1.0f;

    position += speed;

	glutPostRedisplay();


	glutTimerFunc(100, update, 0);
}
void update1(int value)
{

    if(position1 > 1.0)
        position1 = -1.0f;

    position1 += speed1;

	glutPostRedisplay();


	glutTimerFunc(100, update1, 0);
}

void sound()
{

    PlaySound("NationalAnthem.wav", NULL, SND_ASYNC|SND_FILENAME);
    //PlaySound("a.wav", NULL, SND_ASYNC|SND_FILENAME|SND_LOOP);

}

void sound2()
{

    PlaySound(" ", NULL, SND_ASYNC|SND_FILENAME);
    //PlaySound("a.wav", NULL, SND_ASYNC|SND_FILENAME|SND_LOOP);

}

void handleKeypress(unsigned char key, int x, int y) {
	switch (key)
	{
	    case 'd':
        glLoadIdentity();
            glutDisplayFunc(day);
            sound();
            glutPostRedisplay();
            break;
        case 'n':
            glutDisplayFunc(night);
            sound2();
            glutPostRedisplay();
            break;
        //glutPostRedisplay();
	}
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitWindowSize(840, 640);
    glutInitWindowPosition(50, 50);
    glutCreateWindow("Press d: Day, Press n: Night");
    glutDisplayFunc(day);
    glutIdleFunc(Idle);
    glutKeyboardFunc(handleKeypress);
    glutTimerFunc(10, update, 0);
    glutTimerFunc(100, update1, 0);
    glutMainLoop();
    return 0;
}
