#include <iostream>
#include <windows.h>
#include <GL/glut.h>
#include<math.h>
# define PI           3.14159265358979323846

using namespace std;

GLfloat position = 0.0f;
GLfloat position1 = 0.0f;
GLfloat position2 = 0.0f;
GLfloat position3 = 0.0f;
GLfloat position4 = 0.0f;
GLfloat position5 = 0.0f;
GLfloat position6 = 0.0f;
GLfloat speed = 0.01f;//Boat
GLfloat speed1 = 0.003f;//Bus
GLfloat speed2 = 0.01f;//plane

GLfloat positionRain = 0.0f; //Rain
GLfloat speedRain = 0.05f; //Rain
GLfloat positionCloud = 0.0f; //Cloud
GLfloat speedCloud = 0.001f; //Cloud


void Idle()
{
    glutPostRedisplay();
}
//used for Bus(X)
void update(int value) {

    if(position <-1.0)
        position = 1.0f;

    position -= speed1;

	glutPostRedisplay();


	glutTimerFunc(320, update, 0);
}
//used for Bus(Y)
void update4(int value) {

    if(position3 >1.0)
        position3 = -1.0f;

    position3 += speed1;

	glutPostRedisplay();


	glutTimerFunc(100, update4, 0);
}
//used for Bus2(Y)
void update5(int value) {

    if(position4 <-1.0)
        position4 = 1.0f;

    position4 -= speed1;

	glutPostRedisplay();


	glutTimerFunc(100, update5, 0);
}
//used for Small Boat
void update1(int value) {

    if(position1 <-1.0)
        position1 = 1.0f;

    position1 -= speed;

	glutPostRedisplay();


	glutTimerFunc(100, update1, 0);
}

//used for Large Boat
void update2(int value) {

    if(position2 >1.5)
        position2 = -1.0f;

    position2 += speed;

	glutPostRedisplay();


	glutTimerFunc(100, update2, 0);
}
//used for Bus2(X)
void update6(int value) {

    if(position5 >1.5)
        position5 = -1.0f;

    position5 += speed1;

	glutPostRedisplay();


	glutTimerFunc(200, update6, 0);
}
//used for plane
void update7(int value) {

    if(position6 >2)
        position6 = -1.0f;

    position6 += speed2;

	glutPostRedisplay();


	glutTimerFunc(100, update7, 0);
}
void updateRain(int value) {

    if(positionRain <-1.0)
        positionRain = 1.0f;

    positionRain -= speedRain;

	glutPostRedisplay();


	glutTimerFunc(100, updateRain, 0);
}
//used for Cloud
void updateCloud(int value) {

    if(positionCloud >1.5)
        positionCloud = -1.0f;

    positionCloud += speedCloud;

	glutPostRedisplay();


	glutTimerFunc(100, updateCloud, 0);
}


void displayRain(){
    //RAIN
    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, 1.05, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, 0.90, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, 0.75, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, 0.60, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, 0.45, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, 0.30, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, 0.15, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();


    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, -0.30, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, -0.15, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();


    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, -0.45, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, -0.15, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();


    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, -0.60, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, -0.15, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, -0.75, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();
    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, -0.15, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, -0.90, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, -0.15, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, -1.05, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, -0.15, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, -1.20, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, -0.15, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, -1.35, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, -0.15, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, -1.50, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, -0.15, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, -1.65, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, -0.15, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, -1.75, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, -0.15, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, -1.90, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();


    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, -2.05, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, -2.20, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, -2.35, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, -2.50, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, -2.65, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0.0f,positionRain, 0.0f);
    glTranslatef(0.0, -2.75, 0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();

    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glTranslatef(0.08,0.0,0.0);
    glLineWidth(2.5);
    glBegin(GL_LINES);
    glColor3ub(179, 255, 255);
    glVertex2f(-1.00f,1.00f);
    glVertex2f(-0.98f,0.95f);
    glEnd();
    glLoadIdentity();
    glPopMatrix();

    glFlush();
}


void displayDay() {
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT);

	//background upper
	glBegin(GL_QUADS);
    glColor3ub(217, 217, 217);
	glVertex2f(-1.0f, 1.0f);
	glVertex2f(-1.0f, 0.8f);
	glVertex2f(1.0f, 0.8f);
	glVertex2f(1.0f, 1.0f);
    glEnd();

    //background bottom
    glBegin(GL_QUADS);
    glColor3ub(102, 153, 255);
	glVertex2f(-1.0f, 0.8f);
	glVertex2f(-1.0f, -1.0f);
	glVertex2f(1.0f, -1.0f);
	glVertex2f(1.0f, 0.8f);
    glEnd();





    //BoatSmall
    glPushMatrix();
    glTranslatef(position1,0,0);

    glTranslatef(0.4f,0.85f,0.0f);
    glBegin(GL_QUADS);
    glColor3ub(255, 194, 102);
    glVertex2f(-0.5f, -0.68f);
	glVertex2f(-0.48f, -0.72f);
	glVertex2f(-0.3f, -0.72f);
	glVertex2f(-0.28f, -0.68f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 194, 102);
    glVertex2f(-0.31f, -0.65f);
	glVertex2f(-0.31f, -0.68f);
	glVertex2f(-0.28f, -0.68f);
	glVertex2f(-0.28f, -0.65f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(45, 45, 134);
    glVertex2f(-0.45f, -0.63f);
	glVertex2f(-0.45f, -0.68f);
	glVertex2f(-0.35f, -0.68f);
	glVertex2f(-0.35f, -0.63f);
    glEnd();

    glLineWidth(3);

    glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
	glVertex2f(-0.29f, -0.65f);
	glVertex2f(-0.29f, -0.61f);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(255, 77, 77);
	glVertex2f(-0.29f, -0.61f);
	glVertex2f(-0.29f, -0.64f);
	glVertex2f(-0.26f, -0.63f);
    glEnd();

    glPopMatrix();
    glLoadIdentity();



    //BoatBig
    glPushMatrix();
    glTranslatef(position2,0,0);
	//mainBody
    glBegin(GL_QUADS);
    glColor3ub(204, 204, 0);
	glVertex2f(-0.95f, -0.8f);
	glVertex2f(-0.9f, -0.9f);
	glVertex2f(-0.65f, -0.9f);
	glVertex2f(-0.6f, -0.8f);
    glEnd();


    //ceiling
    glBegin(GL_QUADS);
    glColor3ub(204, 204, 255);
    glVertex2f(-0.85f, -0.75f);
	glVertex2f(-0.85f, -0.8f);
	glVertex2f(-0.7f, -0.8f);
	glVertex2f(-0.7f, -0.75f);
    glEnd();


    //sailHolder
    glLineWidth(2.5);
    glBegin(GL_LINES);
	glColor3ub(204, 204, 255);
	glVertex2f(-0.71f, -0.75f);
	glVertex2f(-0.71f, -0.6f);
	glEnd();


	//sailBig
	glBegin(GL_TRIANGLES);
	glColor3ub(204, 102, 0);
	glVertex2f(-0.7f, -0.6f);
	glVertex2f(-0.7f, -0.75f);
	glVertex2f(-0.65f, -0.75f);
	glEnd();


	//sailConnector1
	glLineWidth(1);
    glBegin(GL_LINES);
	glColor3ub(204, 204, 255);
	glVertex2f(-0.7f, -0.6f);
	glVertex2f(-0.71f, -0.6f);
	glEnd();

	//sailSmall
	glBegin(GL_TRIANGLES);
	glColor3ub(204, 102, 0);
	glVertex2f(-0.72f, -0.6f);
	glVertex2f(-0.72f, -0.72f);
	glVertex2f(-0.77f, -0.72f);
	glEnd();

	//sailConnector2
	glLineWidth(1);
    glBegin(GL_LINES);
	glColor3ub(204, 204, 255);
	glVertex2f(-0.7f, -0.6f);
	glVertex2f(-0.72f, -0.6f);
	glEnd();

	//sailConnector3
	glLineWidth(1);
    glBegin(GL_LINES);
	glColor3ub(204, 204, 255);
	glVertex2f(-0.72f, -0.72f);
	glVertex2f(-0.71f, -0.72f);
	glEnd();

	//sailConnector4
	glLineWidth(1);
    glBegin(GL_LINES);
	glColor3ub(204, 204, 255);
	glVertex2f(-0.71f, -0.6f);
	glVertex2f(-0.75f, -0.75f);
	glEnd();

	//flagHolder
	glLineWidth(1);
    glBegin(GL_LINES);
	glColor3ub(204, 204, 255);
	glVertex2f(-0.95f, -0.8f);
	glVertex2f(-0.95f, -0.7f);
	glEnd();

	//flag
	glBegin(GL_TRIANGLES);
	glColor3ub(204, 102, 0);
	glVertex2f(-0.95f, -0.7f);
	glVertex2f(-0.95f, -0.75f);
	glVertex2f(-0.98f, -0.75f);
	glEnd();
	glPopMatrix();
    glLoadIdentity();




 int bridge=0;

    //bridge
    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-1.0f, 0.75f);
	glVertex2f(-0.9f, 0.75f);
	glVertex2f(-0.9f, 0.8f);
	glVertex2f(-1.0f, 0.8f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.9f, 0.75f);
	glVertex2f(-0.8f, 0.74f);
	glVertex2f(-0.8f, 0.79f);
	glVertex2f(-0.9f, 0.8f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.8f, 0.74f);
	glVertex2f(-0.7f, 0.73f);
	glVertex2f(-0.7f, 0.78f);
	glVertex2f(-0.8f, 0.79f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.7f, 0.73f);
	glVertex2f(-0.6f, 0.71f);
	glVertex2f(-0.6f, 0.77f);
	glVertex2f(-0.7f, 0.78f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.6f, 0.71f);
	glVertex2f(-0.5f, 0.69f);
	glVertex2f(-0.5f, 0.76f);
	glVertex2f(-0.6f, 0.77f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.5f, 0.69f);
	glVertex2f(-0.4f, 0.67f);
	glVertex2f(-0.4f, 0.75f);
	glVertex2f(-0.5f, 0.76f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.4f, 0.67f);
	glVertex2f(-0.3f, 0.64f);
	glVertex2f(-0.3f, 0.74f);
	glVertex2f(-0.4f, 0.75f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.3f, 0.64f);
	glVertex2f(-0.2f, 0.61f);
	glVertex2f(-0.2f, 0.73f);
	glVertex2f(-0.3f, 0.74f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.2f, 0.61f);
	glVertex2f(-0.1f, 0.58f);
	glVertex2f(-0.1f, 0.72f);
	glVertex2f(-0.2f, 0.73f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.1f, 0.58f);
	glVertex2f(0.0f, 0.53f);
	glVertex2f(0.0f, 0.70f);
	glVertex2f(-0.1f, 0.72f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(0.0f, 0.53f);
	glVertex2f(0.1f, 0.47f);
	glVertex2f(0.1f, 0.68f);
	glVertex2f(0.0f, 0.70f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(0.1f, 0.47f);
	glVertex2f(0.2f, 0.40f);
	glVertex2f(0.2f, 0.65f);
	glVertex2f(0.1f, 0.68f);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 51, 0);
    glVertex2f(0.2f, 0.65f);
	glVertex2f(0.2f, 0.40f);
	glVertex2f(0.3f, 0.59f);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 51, 0);
	glVertex2f(0.3f, 0.59f);
	glVertex2f(0.2f, 0.40f);
	glVertex2f(0.5f, 0.4f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(0.5f, 0.4f);
	glVertex2f(0.2f, 0.40f);
	glVertex2f(0.5f, -0.2f);
	glVertex2f(0.9f, -0.2f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(0.5f, -0.2f);
	glVertex2f(0.75f, -1.3f);
	glVertex2f(1.3f, -0.8f);
	glVertex2f(0.9f, -0.2f);
    glEnd();


    //////////////

    int road=0;

    //Road separator
    glLineWidth(2);

    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,0.0f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,0.0f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,0.0f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.009f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.005f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.005f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.005f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.007f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.008f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.009f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.01f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.01f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glLineWidth(3);

    glTranslatef(0.05f,-0.01f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.01f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();
    glLoadIdentity();

     glLineWidth(3);

    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.01f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.009f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.008f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.008f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.01f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.02f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.03f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.03f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.03f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.03f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.04f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.07f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();


    glTranslatef(0.05f,-0.08f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.05f,-0.08f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.05f,-0.08f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.05f,-0.08f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.05f,-0.08f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.05f,-0.085f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.03f,-0.1f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.03f,-0.1f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.03f,-0.1f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.04f,-0.1f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.04f,-0.1f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.04f,-0.1f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.04f,-0.1f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();


    glTranslatef(0.04f,-0.1f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();
    glLoadIdentity();

    /////////////


    glLineWidth(2);
    //down1
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-1.0f, 0.75f);
	glVertex2f(-0.9f, 0.75f);
    glEnd();

    //up1
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-1.0f, 0.8f);
	glVertex2f(-0.9f, 0.8f);
    glEnd();

    //down2
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.9f, 0.75f);
	glVertex2f(-0.8f, 0.74f);
    glEnd();

    //up2
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.9f, 0.8f);
	glVertex2f(-0.8f, 0.79f);
    glEnd();

    //down3
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.8f, 0.74f);
	glVertex2f(-0.7f, 0.73f);
    glEnd();

    //up3
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.8f, 0.79f);
	glVertex2f(-0.7f, 0.78f);
    glEnd();

    //down4
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.7f, 0.73f);
	glVertex2f(-0.5f, 0.69f);
    glEnd();

    //up4
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.7f, 0.78f);
	glVertex2f(-0.5f, 0.76f);
    glEnd();

    //down5
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.5f, 0.69f);
	glVertex2f(-0.3f, 0.64f);
    glEnd();

    //up5
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.5f, 0.76f);
	glVertex2f(-0.3f, 0.74f);
    glEnd();

    //down6
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.3f, 0.64f);
	glVertex2f(-0.1f, 0.58f);
    glEnd();

    //up6
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.3f, 0.74f);
	glVertex2f(-0.1f, 0.72f);
    glEnd();


    //down7
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.1f, 0.58f);
	glVertex2f(0.1f, 0.47f);
    glEnd();

    //up7
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.1f, 0.72f);
	glVertex2f(0.1f, 0.68f);
    glEnd();


    //down8
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(0.1f, 0.47f);
	glVertex2f(0.2f, 0.4f);
    glEnd();

    //up8
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(0.1f, 0.68f);
	glVertex2f(0.2f, 0.65f);
    glEnd();

    glLineWidth(3);
    //down9
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(0.2f, 0.4f);
	glVertex2f(0.5f, -0.2f);
    glEnd();

    glLineWidth(2);
    //up9
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(0.2f, 0.65f);
	glVertex2f(0.3f, 0.59f);
    glEnd();

    //up9
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(0.3f, 0.59f);
	glVertex2f(0.5f, 0.4f);
    glEnd();

    glLineWidth(3);
    //down9
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(0.5f, -0.2f);
	glVertex2f(0.684f, -1.0f);
    glEnd();

    //up9
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(0.5f, 0.4f);
	glVertex2f(1.1f, -0.5f);
    glEnd();

    ////////////

    int pillar=0;

    glLineWidth(3);

    //pillar1
    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.98f, 0.745f);
	glVertex2f(-0.96f, 0.72f);
	glVertex2f(-0.94f, 0.72f);
	glVertex2f(-0.92f, 0.745f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.96f, 0.72f);
	glVertex2f(-0.96f, 0.65f);
	glVertex2f(-0.94f, 0.65f);
	glVertex2f(-0.94f, 0.72f);
    glEnd();

    //pillar2
    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.86f, 0.74f);
	glVertex2f(-0.84f, 0.715f);
	glVertex2f(-0.82f, 0.715f);
	glVertex2f(-0.80f, 0.74f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.84f, 0.715f);
	glVertex2f(-0.84f, 0.65f);
	glVertex2f(-0.82f, 0.65f);
	glVertex2f(-0.82f, 0.715f);
    glEnd();
    glLoadIdentity();


    //pillar3
    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.74f, 0.73f);
	glVertex2f(-0.72f, 0.7f);
	glVertex2f(-0.70f, 0.7f);
	glVertex2f(-0.68f, 0.721f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.72f, 0.7f);
	glVertex2f(-0.72f, 0.64f);
	glVertex2f(-0.70f, 0.64f);
	glVertex2f(-0.70f, 0.7f);
    glEnd();


    //pillar4
    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.62f, 0.71f);
	glVertex2f(-0.6f, 0.68f);
	glVertex2f(-0.58f, 0.68f);
	glVertex2f(-0.56f, 0.7f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.6f, 0.68f);
	glVertex2f(-0.6f, 0.62f);
	glVertex2f(-0.58f, 0.62f);
	glVertex2f(-0.58f, 0.68f);
    glEnd();

    //pillar5
    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.50f, 0.685f);
	glVertex2f(-0.48f, 0.66f);
	glVertex2f(-0.46f, 0.655f);
	glVertex2f(-0.44f, 0.67f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.48f, 0.66f);
	glVertex2f(-0.48f, 0.6f);
	glVertex2f(-0.46f, 0.6f);
	glVertex2f(-0.46f, 0.655f);
    glEnd();

    //pillar6
    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.38f, 0.655f);
	glVertex2f(-0.36f, 0.625f);
	glVertex2f(-0.34f, 0.622f);
	glVertex2f(-0.32f, 0.64f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.36f, 0.625f);
	glVertex2f(-0.36f, 0.56f);
	glVertex2f(-0.34f, 0.56f);
	glVertex2f(-0.34f, 0.622f);
    glEnd();

    //pillar7
    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.24f, 0.62f);
	glVertex2f(-0.21f, 0.58f);
	glVertex2f(-0.18f, 0.57f);
	glVertex2f(-0.15f, 0.59f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.21f, 0.58f);
	glVertex2f(-0.21f, 0.5f);
	glVertex2f(-0.18f, 0.5f);
	glVertex2f(-0.18f, 0.57f);
    glEnd();

    //pillar8
    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.05f, 0.55f);
	glVertex2f(-0.02f, 0.485f);
	glVertex2f(0.01f, 0.48f);
	glVertex2f(0.04f, 0.5f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.02f, 0.485f);
	glVertex2f(-0.02f, 0.42f);
	glVertex2f(0.02f, 0.42f);
	glVertex2f(0.02f, 0.49f);
    glEnd();

    //pillar9
    glBegin(GL_TRIANGLES);
    glColor3ub(0, 51, 0);
    glVertex2f(0.1f, 0.465f);
	glVertex2f(0.13f, 0.4f);
	glVertex2f(0.2f, 0.395f);
	glEnd();

	glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(0.13f, 0.4f);
	glVertex2f(0.13f, 0.3f);
	glVertex2f(0.2f, 0.3f);
	glVertex2f(0.2f, 0.395f);
    glEnd();

    //pillar9
    glBegin(GL_TRIANGLES);
    glColor3ub(0, 51, 0);
    glVertex2f(0.31f, 0.17f);
	glVertex2f(0.31f, -0.01f);
	glVertex2f(0.385f, 0.02f);
	glEnd();

	//pillar10
    glBegin(GL_TRIANGLES);
    glColor3ub(0, 51, 0);
    glVertex2f(0.5f, -0.22f);
	glVertex2f(0.5f, -0.39f);
	glVertex2f(0.54f, -0.38f);
	glEnd();


	/////////////

	int epillar=0;
	//electricity pillar
	glLineWidth(2);

	//up1
	glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.98f, 0.85f);
	glVertex2f(-0.98f, 0.8f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.99f, 0.84f);
	glVertex2f(-0.97f, 0.86f);
    glEnd();

    //up2
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.92f, 0.85f);
	glVertex2f(-0.92f, 0.8f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.93f, 0.84f);
	glVertex2f(-0.91f, 0.86f);
    glEnd();

    //up3
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.86f, 0.85f);
	glVertex2f(-0.86f, 0.8f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.87f, 0.84f);
	glVertex2f(-0.85f, 0.86f);
    glEnd();

    //up4
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.80f, 0.85f);
	glVertex2f(-0.80f, 0.79f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.81f, 0.84f);
	glVertex2f(-0.79f, 0.86f);
    glEnd();

    //up5
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.74f, 0.85f);
	glVertex2f(-0.74f, 0.78f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.75f, 0.84f);
	glVertex2f(-0.73f, 0.86f);
    glEnd();


    //up6
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.67f, 0.85f);
	glVertex2f(-0.67f, 0.77f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.68f, 0.84f);
	glVertex2f(-0.66f, 0.86f);
    glEnd();


    //up7
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.60f, 0.85f);
	glVertex2f(-0.60f, 0.76f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.61f, 0.84f);
	glVertex2f(-0.59f, 0.86f);
    glEnd();



    //up8
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.51f, 0.85f);
	glVertex2f(-0.51f, 0.75f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.52f, 0.84f);
	glVertex2f(-0.50f, 0.86f);
    glEnd();

    //up9
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.41f, 0.85f);
	glVertex2f(-0.41f, 0.74f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.42f, 0.84f);
	glVertex2f(-0.40f, 0.86f);
    glEnd();

    //up10
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.30f, 0.85f);
	glVertex2f(-0.30f, 0.73f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.31f, 0.84f);
	glVertex2f(-0.29f, 0.86f);
    glEnd();

    //up11
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.18f, 0.85f);
	glVertex2f(-0.18f, 0.72f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.19f, 0.84f);
	glVertex2f(-0.17f, 0.86f);
    glEnd();


    //up12
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.06f, 0.85f);
	glVertex2f(-0.06f, 0.71f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.07f, 0.84f);
	glVertex2f(-0.05f, 0.86f);
    glEnd();

    //up13
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.06f, 0.85f);
	glVertex2f(0.06f, 0.69f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.05f, 0.84f);
	glVertex2f(0.07f, 0.86f);
    glEnd();


    //up14
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.20f, 0.85f);
	glVertex2f(0.20f, 0.64f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.18f, 0.84f);
	glVertex2f(0.22f, 0.86f);
    glEnd();

    //up15
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.32f, 0.83f);
	glVertex2f(0.32f, 0.57f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.30f, 0.82f);
	glVertex2f(0.34f, 0.84f);
    glEnd();

    //up16
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.44f, 0.76f);
	glVertex2f(0.44f, 0.46f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.42f, 0.75f);
	glVertex2f(0.46f, 0.77f);
    glEnd();


    //up17
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.58f, 0.63f);
	glVertex2f(0.58f, 0.28f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.55f, 0.61f);
	glVertex2f(0.61f, 0.66f);
    glEnd();


    //up18
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.72f, 0.44f);
	glVertex2f(0.72f, 0.07f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.69f, 0.42f);
	glVertex2f(0.76f, 0.47f);
    glEnd();

    //up19
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.87f, 0.3f);
	glVertex2f(0.87f, -0.15f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.83f, 0.27f);
	glVertex2f(0.9f, 0.32f);
    glEnd();


    //////////


    intb  wire=0;
    //wire
    glLineWidth(0.5);

    //down1
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-1.0f, 0.84f);
	glVertex2f(-0.93f, 0.84f);
    glEnd();

    //up1
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-1.0f, 0.86f);
	glVertex2f(-0.91f, 0.86f);
    glEnd();

    //down2
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.93f, 0.84f);
	glVertex2f(-0.87f, 0.84f);
    glEnd();

    //up2
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.91f, 0.86f);
	glVertex2f(-0.85f, 0.86f);
    glEnd();

    //down3
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.87f, 0.84f);
	glVertex2f(-0.81f, 0.84f);
    glEnd();

    //up3
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
    glVertex2f(-0.85f, 0.86f);
	glVertex2f(-0.79f, 0.86f);
    glEnd();

    //down4
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.81f, 0.84f);
	glVertex2f(-0.75f, 0.84f);
    glEnd();

    //up4
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.79f, 0.86f);
	glVertex2f(-0.73f, 0.86f);
    glEnd();

    //down5
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.75f, 0.84f);
	glVertex2f(-0.68f, 0.84f);
    glEnd();

    //up5
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.73f, 0.86f);
	glVertex2f(-0.66f, 0.86f);
    glEnd();

    //down6
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.75f, 0.84f);
	glVertex2f(-0.68f, 0.84f);
    glEnd();

    //up6
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.73f, 0.86f);
	glVertex2f(-0.66f, 0.86f);
    glEnd();

    //down7
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.68f, 0.84f);
	glVertex2f(-0.61f, 0.84f);
    glEnd();

    //up7
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.66f, 0.86f);
	glVertex2f(-0.59f, 0.86f);
    glEnd();

    //down8
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.61f, 0.84f);
	glVertex2f(-0.52f, 0.84f);
    glEnd();

    //up8
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.59f, 0.86f);
	glVertex2f(-0.50f, 0.86f);
    glEnd();


    //down9
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.52f, 0.84f);
	glVertex2f(-0.42f, 0.84f);
    glEnd();

    //up9
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.50f, 0.86f);
	glVertex2f(-0.40f, 0.86f);
    glEnd();

    //down10
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.42f, 0.84f);
	glVertex2f(-0.31f, 0.84f);
    glEnd();

    //up10
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.40f, 0.86f);
	glVertex2f(-0.29f, 0.86f);
    glEnd();

    //down11
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.31f, 0.84f);
	glVertex2f(-0.19f, 0.84f);
    glEnd();

    //up11
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
    glVertex2f(-0.29f, 0.86f);
	glVertex2f(-0.17f, 0.86f);
    glEnd();

    //down12
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.19f, 0.84f);
	glVertex2f(-0.07f, 0.84f);
    glEnd();

    //up12
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.17f, 0.86f);
	glVertex2f(-0.05f, 0.86f);
    glEnd();

    //down13
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.07f, 0.84f);
	glVertex2f(0.05f, 0.84f);
    glEnd();

    //up13
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.05f, 0.86f);
	glVertex2f(0.07f, 0.86f);
    glEnd();

    //down14
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.05f, 0.84f);
	glVertex2f(0.18f, 0.84f);
    glEnd();

    //up14
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.07f, 0.86f);
	glVertex2f(0.22f, 0.86f);
    glEnd();

    //down15
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.18f, 0.84f);
	glVertex2f(0.30f, 0.82f);
    glEnd();

    //up15
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.22f, 0.86f);
	glVertex2f(0.34f, 0.84f);
    glEnd();

    //down16
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.30f, 0.82f);
	glVertex2f(0.42f, 0.75f);
    glEnd();

    //up16
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.34f, 0.84f);
	glVertex2f(0.46f, 0.77f);
    glEnd();

    //down17
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.42f, 0.75f);
	glVertex2f(0.55f, 0.61f);
    glEnd();

    //up17
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.46f, 0.77f);
	glVertex2f(0.61f, 0.66f);
    glEnd();

    //down18
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.55f, 0.61f);
	glVertex2f(0.69f, 0.42f);
    glEnd();

    //up18
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.61f, 0.66f);
	glVertex2f(0.76f, 0.47f);
    glEnd();

   //down19
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.69f, 0.42f);
	glVertex2f(0.83f, 0.27f);
    glEnd();

    //up19
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.76f, 0.47f);
	glVertex2f(0.9f, 0.32f);
    glEnd();

    //down20
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.83f, 0.27f);
	glVertex2f(1.0f, 0.1f);
    glEnd();

    //up20
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(1.0f, 0.24f);
	glVertex2f(0.9f, 0.32f);
    glEnd();


    ///////


    //Bus

    glPushMatrix();
    glTranslatef(position,position3,0);


    //top
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 204);
	glVertex2f(0.7f, -0.7f);
	glVertex2f(0.75f, -0.85f);
	glVertex2f(0.8f, -0.83f);
	glVertex2f(0.73f, -0.69f);
    glEnd();


    //side
    glBegin(GL_QUADS);
    glColor3ub(102, 0, 204);
	glVertex2f(0.7f, -0.7f);
	glVertex2f(0.7f, -0.78f);
	glVertex2f(0.75f, -0.95f);
	glVertex2f(0.75f, -0.85f);
    glEnd();


    //back
    glBegin(GL_QUADS);
    glColor3ub(0, 0, 102);
	glVertex2f(0.75f, -0.85f);
	glVertex2f(0.75f, -0.95f);
	glVertex2f(0.8f, -0.93f);
	glVertex2f(0.8f, -0.83f);
    glEnd();


    //backBottom
    glBegin(GL_QUADS);
    glColor3ub(204, 204, 0);
	glVertex2f(0.75f, -0.85f);
	glVertex2f(0.75f, -0.89f);
	glVertex2f(0.8f, -0.87f);
	glVertex2f(0.8f, -0.83f);
    glEnd();


    //busGlass

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(0.7f, -0.7f);
	glVertex2f(0.691f, -0.69f);
    glEnd();
    glLineWidth(4);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(0.691f, -0.69f);
	glVertex2f(0.691f, -0.71f);
    glEnd();



    //BusWheel
	glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(0.71f, -0.81f);
	glVertex2f(0.71f, -0.82f);
    glEnd();


    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(0.73f, -0.88f);
	glVertex2f(0.73f, -0.89f);
    glEnd();
    glPopMatrix();
    glLoadIdentity();


    //Bus2


    glPushMatrix();
    glTranslatef(position5,position4,0);
    glTranslatef(-0.17f,1.0f,0.0f);
    //top
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 102);
	glVertex2f(0.7f, -0.7f);
	glVertex2f(0.75f, -0.85f);
	glVertex2f(0.8f, -0.83f);
	glVertex2f(0.73f, -0.69f);
    glEnd();


    //side
    glBegin(GL_QUADS);
    glColor3ub(102, 0, 204);
	glVertex2f(0.7f, -0.7f);
	glVertex2f(0.7f, -0.78f);
	glVertex2f(0.75f, -0.95f);
	glVertex2f(0.75f, -0.85f);
    glEnd();


    //back
    glBegin(GL_QUADS);
    glColor3ub(179, 255, 204);
	glVertex2f(0.75f, -0.85f);
	glVertex2f(0.75f, -0.95f);
	glVertex2f(0.8f, -0.93f);
	glVertex2f(0.8f, -0.83f);
    glEnd();


    //backBottom
    glBegin(GL_QUADS);
    glColor3ub(179, 255, 204);
	glVertex2f(0.75f, -0.85f);
	glVertex2f(0.75f, -0.89f);
	glVertex2f(0.8f, -0.87f);
	glVertex2f(0.8f, -0.83f);
    glEnd();

    //BusWheel
	glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(0.71f, -0.81f);
	glVertex2f(0.71f, -0.82f);
    glEnd();


    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(0.73f, -0.88f);
	glVertex2f(0.73f, -0.89f);
    glEnd();
    glPopMatrix();
    glLoadIdentity();


    int lamp = 0;

    //Lamp

    //lamp1
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.95f, 0.8f);
	glVertex2f(-0.95f, 0.75f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.95f, 0.8f);
	glVertex2f(-0.94f, 0.81f);
    glEnd();

    //lamp2
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.89f, 0.8f);
	glVertex2f(-0.89f, 0.75f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.89f, 0.8f);
	glVertex2f(-0.88f, 0.81f);
    glEnd();

    //lamp3
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.83f, 0.8f);
	glVertex2f(-0.83f, 0.74f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.83f, 0.8f);
	glVertex2f(-0.82f, 0.81f);
    glEnd();


    //lamp4
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.77f, 0.8f);
	glVertex2f(-0.77f, 0.74f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.77f, 0.8f);
	glVertex2f(-0.76f, 0.81f);
    glEnd();



    //lamp5
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.71f, 0.8f);
	glVertex2f(-0.71f, 0.73f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.71f, 0.8f);
	glVertex2f(-0.7f, 0.81f);
    glEnd();


    //lamp6
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.64f, 0.8f);
	glVertex2f(-0.64f, 0.72f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.64f, 0.8f);
	glVertex2f(-0.63, 0.81f);
    glEnd();


    //lamp7
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.56f, 0.8f);
	glVertex2f(-0.56f, 0.70f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.56f, 0.8f);
	glVertex2f(-0.55, 0.81f);
    glEnd();


    //lamp8
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.47f, 0.8f);
	glVertex2f(-0.47f, 0.68f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.47f, 0.8f);
	glVertex2f(-0.46, 0.81f);
    glEnd();


    //lamp9
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.35f, 0.8f);
	glVertex2f(-0.35f, 0.65f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.35f, 0.8f);
	glVertex2f(-0.33, 0.82f);
    glEnd();

    //lamp10
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.24f, 0.8f);
	glVertex2f(-0.24f, 0.62f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.24f, 0.8f);
	glVertex2f(-0.22, 0.82f);
    glEnd();


    //lamp11
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.12f, 0.8f);
	glVertex2f(-0.12f, 0.59f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.12f, 0.8f);
	glVertex2f(-0.10, 0.82f);
    glEnd();

    //lamp12
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.0f, 0.8f);
	glVertex2f(-0.0f, 0.53f);
    glEnd();

    glLineWidth(4);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.0f, 0.8f);
	glVertex2f(0.03, 0.83f);
    glEnd();

    //lamp13
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.13f, 0.8f);
	glVertex2f(0.13f, 0.45f);
    glEnd();

    glLineWidth(4);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.13f, 0.8f);
	glVertex2f(0.16, 0.83f);
    glEnd();


    //lamp14
    glLineWidth(2.2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.25f, 0.69f);
	glVertex2f(0.25f, 0.30f);
    glEnd();

    glLineWidth(5);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.25f, 0.69f);
	glVertex2f(0.29, 0.75f);
    glEnd();

    //lamp15
    glLineWidth(2.5);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.35f, 0.6f);
	glVertex2f(0.35f, 0.1f);
    glEnd();

    glLineWidth(5);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.35f, 0.6f);
	glVertex2f(0.39, 0.66f);
    glEnd();


    //lamp16
    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.47f, 0.45f);
	glVertex2f(0.47f, -0.14f);
    glEnd();

    glLineWidth(6);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.47f, 0.45f);
	glVertex2f(0.52, 0.53f);
    glEnd();


    //lamp17
    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.6f, 0.1f);
	glVertex2f(0.6f, -0.62f);
    glEnd();

    glLineWidth(7);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.6f, 0.1f);
	glVertex2f(0.65, 0.21f);
    glEnd();

    //Sun

    int i;
	GLfloat twicePi = 2.0f * PI;

    GLfloat x3= 0.71f; GLfloat y3= 0.93f; GLfloat radius2 = 0.03f;
	int triangleAmount = 100;


	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 102);
		glVertex2f(x3, y3); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x3 + (radius2 * cos(i *  twicePi / triangleAmount)),
			    y3 + (radius2 * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();


	int plane =0;

	//plane                                  //To Speed up Press: Left Mouse B.
	                                         //To Speed down Press: Right Mouse B.
	glTranslatef(position6,0,0);
	glTranslatef(-0.8f,0.05f,0.0f);
	glBegin(GL_QUADS);
    glColor3ub(0, 0, 128);
    glVertex2f(-0.08f, 0.9f);
	glVertex2f(-0.08f, 0.88f);
	glVertex2f(0.12f, 0.88f);
	glVertex2f(0.1f, 0.9f);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 0, 128);
    glVertex2f(-0.1f, 0.92f);
    glVertex2f(-0.08f, 0.9f);
	glVertex2f(-0.08f, 0.88f);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 0, 128);
    glVertex2f(-0.01f, 0.88f);
    glVertex2f(-0.02f, 0.86f);
	glVertex2f(0.0f, 0.88f);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 0, 128);
    glVertex2f(-0.01f, 0.9f);
    glVertex2f(-0.02f, 0.92f);
	glVertex2f(0.0f, 0.9f);
    glEnd();
    glLoadIdentity();

glFlush();
}





              ///////////For Evening View//////////








void displayEvening() {
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT);

	//background upper
	glBegin(GL_QUADS);
    glColor3ub(255, 209, 179);
	glVertex2f(-1.0f, 1.0f);
	glVertex2f(-1.0f, 0.8f);
	glVertex2f(1.0f, 0.8f);
	glVertex2f(1.0f, 1.0f);
    glEnd();


    //Sun

    int i;
	GLfloat twicePi = 2.0f * PI;

    GLfloat x= 0.07f; GLfloat y= 0.81f; GLfloat radius = 0.05f;
	int triangleAmount = 100;


	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 0);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();


    //background bottom
    glBegin(GL_QUADS);
    glColor3ub(0, 0, 204);
	glVertex2f(-1.0f, 0.8f);
	glVertex2f(-1.0f, -1.0f);
	glVertex2f(1.0f, -1.0f);
	glVertex2f(1.0f, 0.8f);
    glEnd();





    //BoatSmall
    glPushMatrix();
    glTranslatef(position1,0,0);

    glTranslatef(0.4f,0.85f,0.0f);
    glBegin(GL_QUADS);
    glColor3ub(255, 194, 102);
    glVertex2f(-0.5f, -0.68f);
	glVertex2f(-0.48f, -0.72f);
	glVertex2f(-0.3f, -0.72f);
	glVertex2f(-0.28f, -0.68f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 194, 102);
    glVertex2f(-0.31f, -0.65f);
	glVertex2f(-0.31f, -0.68f);
	glVertex2f(-0.28f, -0.68f);
	glVertex2f(-0.28f, -0.65f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(45, 45, 134);
    glVertex2f(-0.45f, -0.63f);
	glVertex2f(-0.45f, -0.68f);
	glVertex2f(-0.35f, -0.68f);
	glVertex2f(-0.35f, -0.63f);
    glEnd();

    glLineWidth(3);

    glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
	glVertex2f(-0.29f, -0.65f);
	glVertex2f(-0.29f, -0.61f);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(255, 77, 77);
	glVertex2f(-0.29f, -0.61f);
	glVertex2f(-0.29f, -0.64f);
	glVertex2f(-0.26f, -0.63f);
    glEnd();

    glPopMatrix();
    glLoadIdentity();


    //bridge
    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-1.0f, 0.75f);
	glVertex2f(-0.9f, 0.75f);
	glVertex2f(-0.9f, 0.8f);
	glVertex2f(-1.0f, 0.8f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.9f, 0.75f);
	glVertex2f(-0.8f, 0.74f);
	glVertex2f(-0.8f, 0.79f);
	glVertex2f(-0.9f, 0.8f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.8f, 0.74f);
	glVertex2f(-0.7f, 0.73f);
	glVertex2f(-0.7f, 0.78f);
	glVertex2f(-0.8f, 0.79f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.7f, 0.73f);
	glVertex2f(-0.6f, 0.71f);
	glVertex2f(-0.6f, 0.77f);
	glVertex2f(-0.7f, 0.78f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.6f, 0.71f);
	glVertex2f(-0.5f, 0.69f);
	glVertex2f(-0.5f, 0.76f);
	glVertex2f(-0.6f, 0.77f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.5f, 0.69f);
	glVertex2f(-0.4f, 0.67f);
	glVertex2f(-0.4f, 0.75f);
	glVertex2f(-0.5f, 0.76f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.4f, 0.67f);
	glVertex2f(-0.3f, 0.64f);
	glVertex2f(-0.3f, 0.74f);
	glVertex2f(-0.4f, 0.75f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.3f, 0.64f);
	glVertex2f(-0.2f, 0.61f);
	glVertex2f(-0.2f, 0.73f);
	glVertex2f(-0.3f, 0.74f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.2f, 0.61f);
	glVertex2f(-0.1f, 0.58f);
	glVertex2f(-0.1f, 0.72f);
	glVertex2f(-0.2f, 0.73f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.1f, 0.58f);
	glVertex2f(0.0f, 0.53f);
	glVertex2f(0.0f, 0.70f);
	glVertex2f(-0.1f, 0.72f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(0.0f, 0.53f);
	glVertex2f(0.1f, 0.47f);
	glVertex2f(0.1f, 0.68f);
	glVertex2f(0.0f, 0.70f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(0.1f, 0.47f);
	glVertex2f(0.2f, 0.40f);
	glVertex2f(0.2f, 0.65f);
	glVertex2f(0.1f, 0.68f);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 51, 0);
    glVertex2f(0.2f, 0.65f);
	glVertex2f(0.2f, 0.40f);
	glVertex2f(0.3f, 0.59f);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 51, 0);
	glVertex2f(0.3f, 0.59f);
	glVertex2f(0.2f, 0.40f);
	glVertex2f(0.5f, 0.4f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(0.5f, 0.4f);
	glVertex2f(0.2f, 0.40f);
	glVertex2f(0.5f, -0.2f);
	glVertex2f(0.9f, -0.2f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(0.5f, -0.2f);
	glVertex2f(0.75f, -1.3f);
	glVertex2f(1.3f, -0.8f);
	glVertex2f(0.9f, -0.2f);
    glEnd();


    //////////////


    //Road separator
    glLineWidth(2);

    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,0.0f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,0.0f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,0.0f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.009f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.005f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.005f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.005f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.007f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.008f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.009f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.01f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.01f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glLineWidth(3);

    glTranslatef(0.05f,-0.01f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.01f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();
    glLoadIdentity();

     glLineWidth(3);

    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.01f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.009f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.008f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.008f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.01f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.02f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.03f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.03f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.03f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.03f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.04f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.07f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();


    glTranslatef(0.05f,-0.08f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.05f,-0.08f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.05f,-0.08f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.05f,-0.08f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.05f,-0.08f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.05f,-0.085f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.03f,-0.1f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.03f,-0.1f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.03f,-0.1f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.04f,-0.1f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.04f,-0.1f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.04f,-0.1f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.04f,-0.1f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();


    glTranslatef(0.04f,-0.1f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();
    glLoadIdentity();

    /////////////


    glLineWidth(2);
    //down1
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-1.0f, 0.75f);
	glVertex2f(-0.9f, 0.75f);
    glEnd();

    //up1
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-1.0f, 0.8f);
	glVertex2f(-0.9f, 0.8f);
    glEnd();

    //down2
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.9f, 0.75f);
	glVertex2f(-0.8f, 0.74f);
    glEnd();

    //up2
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.9f, 0.8f);
	glVertex2f(-0.8f, 0.79f);
    glEnd();

    //down3
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.8f, 0.74f);
	glVertex2f(-0.7f, 0.73f);
    glEnd();

    //up3
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.8f, 0.79f);
	glVertex2f(-0.7f, 0.78f);
    glEnd();

    //down4
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.7f, 0.73f);
	glVertex2f(-0.5f, 0.69f);
    glEnd();

    //up4
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.7f, 0.78f);
	glVertex2f(-0.5f, 0.76f);
    glEnd();

    //down5
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.5f, 0.69f);
	glVertex2f(-0.3f, 0.64f);
    glEnd();

    //up5
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.5f, 0.76f);
	glVertex2f(-0.3f, 0.74f);
    glEnd();

    //down6
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.3f, 0.64f);
	glVertex2f(-0.1f, 0.58f);
    glEnd();

    //up6
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.3f, 0.74f);
	glVertex2f(-0.1f, 0.72f);
    glEnd();


    //down7
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.1f, 0.58f);
	glVertex2f(0.1f, 0.47f);
    glEnd();

    //up7
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.1f, 0.72f);
	glVertex2f(0.1f, 0.68f);
    glEnd();


    //down8
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(0.1f, 0.47f);
	glVertex2f(0.2f, 0.4f);
    glEnd();

    //up8
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(0.1f, 0.68f);
	glVertex2f(0.2f, 0.65f);
    glEnd();

    glLineWidth(3);
    //down9
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(0.2f, 0.4f);
	glVertex2f(0.5f, -0.2f);
    glEnd();

    glLineWidth(2);
    //up9
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(0.2f, 0.65f);
	glVertex2f(0.3f, 0.59f);
    glEnd();

    //up9
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(0.3f, 0.59f);
	glVertex2f(0.5f, 0.4f);
    glEnd();

    glLineWidth(3);
    //down9
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(0.5f, -0.2f);
	glVertex2f(0.684f, -1.0f);
    glEnd();

    //up9
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(0.5f, 0.4f);
	glVertex2f(1.1f, -0.5f);
    glEnd();

    ////////////

    glLineWidth(3);

    //pillar1
    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.98f, 0.745f);
	glVertex2f(-0.96f, 0.72f);
	glVertex2f(-0.94f, 0.72f);
	glVertex2f(-0.92f, 0.745f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.96f, 0.72f);
	glVertex2f(-0.96f, 0.65f);
	glVertex2f(-0.94f, 0.65f);
	glVertex2f(-0.94f, 0.72f);
    glEnd();

    //pillar2
    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.86f, 0.74f);
	glVertex2f(-0.84f, 0.715f);
	glVertex2f(-0.82f, 0.715f);
	glVertex2f(-0.80f, 0.74f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.84f, 0.715f);
	glVertex2f(-0.84f, 0.65f);
	glVertex2f(-0.82f, 0.65f);
	glVertex2f(-0.82f, 0.715f);
    glEnd();
    glLoadIdentity();


    //pillar3
    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.74f, 0.73f);
	glVertex2f(-0.72f, 0.7f);
	glVertex2f(-0.70f, 0.7f);
	glVertex2f(-0.68f, 0.721f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.72f, 0.7f);
	glVertex2f(-0.72f, 0.64f);
	glVertex2f(-0.70f, 0.64f);
	glVertex2f(-0.70f, 0.7f);
    glEnd();


    //pillar4
    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.62f, 0.71f);
	glVertex2f(-0.6f, 0.68f);
	glVertex2f(-0.58f, 0.68f);
	glVertex2f(-0.56f, 0.7f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.6f, 0.68f);
	glVertex2f(-0.6f, 0.62f);
	glVertex2f(-0.58f, 0.62f);
	glVertex2f(-0.58f, 0.68f);
    glEnd();

    //pillar5
    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.50f, 0.685f);
	glVertex2f(-0.48f, 0.66f);
	glVertex2f(-0.46f, 0.655f);
	glVertex2f(-0.44f, 0.67f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.48f, 0.66f);
	glVertex2f(-0.48f, 0.6f);
	glVertex2f(-0.46f, 0.6f);
	glVertex2f(-0.46f, 0.655f);
    glEnd();

    //pillar6
    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.38f, 0.655f);
	glVertex2f(-0.36f, 0.625f);
	glVertex2f(-0.34f, 0.622f);
	glVertex2f(-0.32f, 0.64f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.36f, 0.625f);
	glVertex2f(-0.36f, 0.56f);
	glVertex2f(-0.34f, 0.56f);
	glVertex2f(-0.34f, 0.622f);
    glEnd();

    //pillar7
    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.24f, 0.62f);
	glVertex2f(-0.21f, 0.58f);
	glVertex2f(-0.18f, 0.57f);
	glVertex2f(-0.15f, 0.59f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.21f, 0.58f);
	glVertex2f(-0.21f, 0.5f);
	glVertex2f(-0.18f, 0.5f);
	glVertex2f(-0.18f, 0.57f);
    glEnd();

    //pillar8
    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.05f, 0.55f);
	glVertex2f(-0.02f, 0.485f);
	glVertex2f(0.01f, 0.48f);
	glVertex2f(0.04f, 0.5f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.02f, 0.485f);
	glVertex2f(-0.02f, 0.42f);
	glVertex2f(0.02f, 0.42f);
	glVertex2f(0.02f, 0.49f);
    glEnd();

    //pillar9
    glBegin(GL_TRIANGLES);
    glColor3ub(0, 51, 0);
    glVertex2f(0.1f, 0.465f);
	glVertex2f(0.13f, 0.4f);
	glVertex2f(0.2f, 0.395f);
	glEnd();

	glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(0.13f, 0.4f);
	glVertex2f(0.13f, 0.3f);
	glVertex2f(0.2f, 0.3f);
	glVertex2f(0.2f, 0.395f);
    glEnd();

    //pillar9
    glBegin(GL_TRIANGLES);
    glColor3ub(0, 51, 0);
    glVertex2f(0.31f, 0.17f);
	glVertex2f(0.31f, -0.01f);
	glVertex2f(0.385f, 0.02f);
	glEnd();

	//pillar10
    glBegin(GL_TRIANGLES);
    glColor3ub(0, 51, 0);
    glVertex2f(0.5f, -0.22f);
	glVertex2f(0.5f, -0.39f);
	glVertex2f(0.54f, -0.38f);
	glEnd();


	/////////////

	//electricity pillar
	glLineWidth(2);

	//up1
	glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.98f, 0.85f);
	glVertex2f(-0.98f, 0.8f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.99f, 0.84f);
	glVertex2f(-0.97f, 0.86f);
    glEnd();

    //up2
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.92f, 0.85f);
	glVertex2f(-0.92f, 0.8f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.93f, 0.84f);
	glVertex2f(-0.91f, 0.86f);
    glEnd();

    //up3
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.86f, 0.85f);
	glVertex2f(-0.86f, 0.8f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.87f, 0.84f);
	glVertex2f(-0.85f, 0.86f);
    glEnd();

    //up4
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.80f, 0.85f);
	glVertex2f(-0.80f, 0.79f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.81f, 0.84f);
	glVertex2f(-0.79f, 0.86f);
    glEnd();

    //up5
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.74f, 0.85f);
	glVertex2f(-0.74f, 0.78f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.75f, 0.84f);
	glVertex2f(-0.73f, 0.86f);
    glEnd();


    //up6
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.67f, 0.85f);
	glVertex2f(-0.67f, 0.77f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.68f, 0.84f);
	glVertex2f(-0.66f, 0.86f);
    glEnd();


    //up7
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.60f, 0.85f);
	glVertex2f(-0.60f, 0.76f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.61f, 0.84f);
	glVertex2f(-0.59f, 0.86f);
    glEnd();



    //up8
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.51f, 0.85f);
	glVertex2f(-0.51f, 0.75f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.52f, 0.84f);
	glVertex2f(-0.50f, 0.86f);
    glEnd();

    //up9
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.41f, 0.85f);
	glVertex2f(-0.41f, 0.74f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.42f, 0.84f);
	glVertex2f(-0.40f, 0.86f);
    glEnd();

    //up10
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.30f, 0.85f);
	glVertex2f(-0.30f, 0.73f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.31f, 0.84f);
	glVertex2f(-0.29f, 0.86f);
    glEnd();

    //up11
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.18f, 0.85f);
	glVertex2f(-0.18f, 0.72f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.19f, 0.84f);
	glVertex2f(-0.17f, 0.86f);
    glEnd();


    //up12
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.06f, 0.85f);
	glVertex2f(-0.06f, 0.71f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.07f, 0.84f);
	glVertex2f(-0.05f, 0.86f);
    glEnd();

    //up13
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.06f, 0.85f);
	glVertex2f(0.06f, 0.69f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.05f, 0.84f);
	glVertex2f(0.07f, 0.86f);
    glEnd();


    //up14
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.20f, 0.85f);
	glVertex2f(0.20f, 0.64f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.18f, 0.84f);
	glVertex2f(0.22f, 0.86f);
    glEnd();

    //up15
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.32f, 0.83f);
	glVertex2f(0.32f, 0.57f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.30f, 0.82f);
	glVertex2f(0.34f, 0.84f);
    glEnd();

    //up16
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.44f, 0.76f);
	glVertex2f(0.44f, 0.46f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.42f, 0.75f);
	glVertex2f(0.46f, 0.77f);
    glEnd();


    //up17
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.58f, 0.63f);
	glVertex2f(0.58f, 0.28f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.55f, 0.61f);
	glVertex2f(0.61f, 0.66f);
    glEnd();


    //up18
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.72f, 0.44f);
	glVertex2f(0.72f, 0.07f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.69f, 0.42f);
	glVertex2f(0.76f, 0.47f);
    glEnd();

    //up19
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.87f, 0.3f);
	glVertex2f(0.87f, -0.15f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.83f, 0.27f);
	glVertex2f(0.9f, 0.32f);
    glEnd();


    //////////


    //wire
    glLineWidth(0.5);

    //down1
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-1.0f, 0.84f);
	glVertex2f(-0.93f, 0.84f);
    glEnd();

    //up1
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-1.0f, 0.86f);
	glVertex2f(-0.91f, 0.86f);
    glEnd();

    //down2
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.93f, 0.84f);
	glVertex2f(-0.87f, 0.84f);
    glEnd();

    //up2
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.91f, 0.86f);
	glVertex2f(-0.85f, 0.86f);
    glEnd();

    //down3
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.87f, 0.84f);
	glVertex2f(-0.81f, 0.84f);
    glEnd();

    //up3
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
    glVertex2f(-0.85f, 0.86f);
	glVertex2f(-0.79f, 0.86f);
    glEnd();

    //down4
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.81f, 0.84f);
	glVertex2f(-0.75f, 0.84f);
    glEnd();

    //up4
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.79f, 0.86f);
	glVertex2f(-0.73f, 0.86f);
    glEnd();

    //down5
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.75f, 0.84f);
	glVertex2f(-0.68f, 0.84f);
    glEnd();

    //up5
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.73f, 0.86f);
	glVertex2f(-0.66f, 0.86f);
    glEnd();

    //down6
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.75f, 0.84f);
	glVertex2f(-0.68f, 0.84f);
    glEnd();

    //up6
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.73f, 0.86f);
	glVertex2f(-0.66f, 0.86f);
    glEnd();

    //down7
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.68f, 0.84f);
	glVertex2f(-0.61f, 0.84f);
    glEnd();

    //up7
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.66f, 0.86f);
	glVertex2f(-0.59f, 0.86f);
    glEnd();

    //down8
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.61f, 0.84f);
	glVertex2f(-0.52f, 0.84f);
    glEnd();

    //up8
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.59f, 0.86f);
	glVertex2f(-0.50f, 0.86f);
    glEnd();


    //down9
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.52f, 0.84f);
	glVertex2f(-0.42f, 0.84f);
    glEnd();

    //up9
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.50f, 0.86f);
	glVertex2f(-0.40f, 0.86f);
    glEnd();

    //down10
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.42f, 0.84f);
	glVertex2f(-0.31f, 0.84f);
    glEnd();

    //up10
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.40f, 0.86f);
	glVertex2f(-0.29f, 0.86f);
    glEnd();

    //down11
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.31f, 0.84f);
	glVertex2f(-0.19f, 0.84f);
    glEnd();

    //up11
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
    glVertex2f(-0.29f, 0.86f);
	glVertex2f(-0.17f, 0.86f);
    glEnd();

    //down12
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.19f, 0.84f);
	glVertex2f(-0.07f, 0.84f);
    glEnd();

    //up12
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.17f, 0.86f);
	glVertex2f(-0.05f, 0.86f);
    glEnd();

    //down13
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.07f, 0.84f);
	glVertex2f(0.05f, 0.84f);
    glEnd();

    //up13
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.05f, 0.86f);
	glVertex2f(0.07f, 0.86f);
    glEnd();

    //down14
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.05f, 0.84f);
	glVertex2f(0.18f, 0.84f);
    glEnd();

    //up14
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.07f, 0.86f);
	glVertex2f(0.22f, 0.86f);
    glEnd();

    //down15
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.18f, 0.84f);
	glVertex2f(0.30f, 0.82f);
    glEnd();

    //up15
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.22f, 0.86f);
	glVertex2f(0.34f, 0.84f);
    glEnd();

    //down16
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.30f, 0.82f);
	glVertex2f(0.42f, 0.75f);
    glEnd();

    //up16
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.34f, 0.84f);
	glVertex2f(0.46f, 0.77f);
    glEnd();

    //down17
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.42f, 0.75f);
	glVertex2f(0.55f, 0.61f);
    glEnd();

    //up17
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.46f, 0.77f);
	glVertex2f(0.61f, 0.66f);
    glEnd();

    //down18
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.55f, 0.61f);
	glVertex2f(0.69f, 0.42f);
    glEnd();

    //up18
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.61f, 0.66f);
	glVertex2f(0.76f, 0.47f);
    glEnd();

   //down19
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.69f, 0.42f);
	glVertex2f(0.83f, 0.27f);
    glEnd();

    //up19
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.76f, 0.47f);
	glVertex2f(0.9f, 0.32f);
    glEnd();

    //down20
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.83f, 0.27f);
	glVertex2f(1.0f, 0.1f);
    glEnd();

    //up20
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(1.0f, 0.24f);
	glVertex2f(0.9f, 0.32f);
    glEnd();


    ///////


    //Bus

    glPushMatrix();
    glTranslatef(position,position3,0);


    //top
    glBegin(GL_QUADS);
    glColor3ub(255, 255, 204);
	glVertex2f(0.7f, -0.7f);
	glVertex2f(0.75f, -0.85f);
	glVertex2f(0.8f, -0.83f);
	glVertex2f(0.73f, -0.69f);
    glEnd();


    //side
    glBegin(GL_QUADS);
    glColor3ub(102, 0, 204);
	glVertex2f(0.7f, -0.7f);
	glVertex2f(0.7f, -0.78f);
	glVertex2f(0.75f, -0.95f);
	glVertex2f(0.75f, -0.85f);
    glEnd();


    //back
    glBegin(GL_QUADS);
    glColor3ub(0, 0, 102);
	glVertex2f(0.75f, -0.85f);
	glVertex2f(0.75f, -0.95f);
	glVertex2f(0.8f, -0.93f);
	glVertex2f(0.8f, -0.83f);
    glEnd();


    //backBottom
    glBegin(GL_QUADS);
    glColor3ub(204, 204, 0);
	glVertex2f(0.75f, -0.85f);
	glVertex2f(0.75f, -0.89f);
	glVertex2f(0.8f, -0.87f);
	glVertex2f(0.8f, -0.83f);
    glEnd();


    //busGlass

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(0.7f, -0.7f);
	glVertex2f(0.691f, -0.69f);
    glEnd();
    glLineWidth(4);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(0.691f, -0.69f);
	glVertex2f(0.691f, -0.71f);
    glEnd();



    //BusWheel
	glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(0.71f, -0.81f);
	glVertex2f(0.71f, -0.82f);
    glEnd();


    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(0.73f, -0.88f);
	glVertex2f(0.73f, -0.89f);
    glEnd();
    glPopMatrix();
    glLoadIdentity();


    //Bus2


    glPushMatrix();
    glTranslatef(position5,position4,0);
    glTranslatef(-0.17f,1.0f,0.0f);
    //top
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 102);
	glVertex2f(0.7f, -0.7f);
	glVertex2f(0.75f, -0.85f);
	glVertex2f(0.8f, -0.83f);
	glVertex2f(0.73f, -0.69f);
    glEnd();


    //side
    glBegin(GL_QUADS);
    glColor3ub(102, 0, 204);
	glVertex2f(0.7f, -0.7f);
	glVertex2f(0.7f, -0.78f);
	glVertex2f(0.75f, -0.95f);
	glVertex2f(0.75f, -0.85f);
    glEnd();


    //back
    glBegin(GL_QUADS);
    glColor3ub(179, 255, 204);
	glVertex2f(0.75f, -0.85f);
	glVertex2f(0.75f, -0.95f);
	glVertex2f(0.8f, -0.93f);
	glVertex2f(0.8f, -0.83f);
    glEnd();


    //backBottom
    glBegin(GL_QUADS);
    glColor3ub(179, 255, 204);
	glVertex2f(0.75f, -0.85f);
	glVertex2f(0.75f, -0.89f);
	glVertex2f(0.8f, -0.87f);
	glVertex2f(0.8f, -0.83f);
    glEnd();

    //BusWheel
	glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(0.71f, -0.81f);
	glVertex2f(0.71f, -0.82f);
    glEnd();


    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(0.73f, -0.88f);
	glVertex2f(0.73f, -0.89f);
    glEnd();
    glPopMatrix();
    glLoadIdentity();



    //Lamp

    //lamp1
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.95f, 0.8f);
	glVertex2f(-0.95f, 0.75f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.95f, 0.8f);
	glVertex2f(-0.94f, 0.81f);
    glEnd();

    //lamp2
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.89f, 0.8f);
	glVertex2f(-0.89f, 0.75f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.89f, 0.8f);
	glVertex2f(-0.88f, 0.81f);
    glEnd();

    //lamp3
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.83f, 0.8f);
	glVertex2f(-0.83f, 0.74f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.83f, 0.8f);
	glVertex2f(-0.82f, 0.81f);
    glEnd();


    //lamp4
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.77f, 0.8f);
	glVertex2f(-0.77f, 0.74f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.77f, 0.8f);
	glVertex2f(-0.76f, 0.81f);
    glEnd();



    //lamp5
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.71f, 0.8f);
	glVertex2f(-0.71f, 0.73f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.71f, 0.8f);
	glVertex2f(-0.7f, 0.81f);
    glEnd();


    //lamp6
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.64f, 0.8f);
	glVertex2f(-0.64f, 0.72f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.64f, 0.8f);
	glVertex2f(-0.63, 0.81f);
    glEnd();


    //lamp7
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.56f, 0.8f);
	glVertex2f(-0.56f, 0.70f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.56f, 0.8f);
	glVertex2f(-0.55, 0.81f);
    glEnd();


    //lamp8
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.47f, 0.8f);
	glVertex2f(-0.47f, 0.68f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.47f, 0.8f);
	glVertex2f(-0.46, 0.81f);
    glEnd();


    //lamp9
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.35f, 0.8f);
	glVertex2f(-0.35f, 0.65f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.35f, 0.8f);
	glVertex2f(-0.33, 0.82f);
    glEnd();

    //lamp10
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.24f, 0.8f);
	glVertex2f(-0.24f, 0.62f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.24f, 0.8f);
	glVertex2f(-0.22, 0.82f);
    glEnd();


    //lamp11
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.12f, 0.8f);
	glVertex2f(-0.12f, 0.59f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.12f, 0.8f);
	glVertex2f(-0.10, 0.82f);
    glEnd();

    //lamp12
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.0f, 0.8f);
	glVertex2f(-0.0f, 0.53f);
    glEnd();

    glLineWidth(4);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.0f, 0.8f);
	glVertex2f(0.03, 0.83f);
    glEnd();

    //lamp13
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.13f, 0.8f);
	glVertex2f(0.13f, 0.45f);
    glEnd();

    glLineWidth(4);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.13f, 0.8f);
	glVertex2f(0.16, 0.83f);
    glEnd();


    //lamp14
    glLineWidth(2.2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.25f, 0.69f);
	glVertex2f(0.25f, 0.30f);
    glEnd();

    glLineWidth(5);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.25f, 0.69f);
	glVertex2f(0.29, 0.75f);
    glEnd();

    //lamp15
    glLineWidth(2.5);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.35f, 0.6f);
	glVertex2f(0.35f, 0.1f);
    glEnd();

    glLineWidth(5);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.35f, 0.6f);
	glVertex2f(0.39, 0.66f);
    glEnd();


    //lamp16
    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.47f, 0.45f);
	glVertex2f(0.47f, -0.14f);
    glEnd();

    glLineWidth(6);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.47f, 0.45f);
	glVertex2f(0.52, 0.53f);
    glEnd();


    //lamp17
    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.6f, 0.1f);
	glVertex2f(0.6f, -0.62f);
    glEnd();

    glLineWidth(7);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.6f, 0.1f);
	glVertex2f(0.65, 0.21f);
    glEnd();

    int cloud =0;

    glTranslatef(positionCloud,0,0);
    //Clouds1

    GLfloat x1= -0.9f; GLfloat y1= 0.9f; GLfloat radius1 = 0.02f;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 255);
		glVertex2f(x1, y1); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x1 + (radius1 * cos(i *  twicePi / triangleAmount)),
			    y1 + (radius1 * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();


	GLfloat x2= -0.88f; GLfloat y2= 0.92f; GLfloat radius2 = 0.02f;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 255);
		glVertex2f(x2, y2); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x2 + (radius2 * cos(i *  twicePi / triangleAmount)),
			    y2 + (radius2 * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();



	GLfloat x3= -0.88f; GLfloat y3= 0.89f; GLfloat radius3 = 0.02f;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 255);
		glVertex2f(x3, y3); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x3 + (radius3 * cos(i *  twicePi / triangleAmount)),
			    y3 + (radius3 * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();



	//Clouds2

    GLfloat x4= -0.8f; GLfloat y4= 0.9f; GLfloat radius4 = 0.02f;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 255);
		glVertex2f(x4, y4); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x4 + (radius4 * cos(i *  twicePi / triangleAmount)),
			    y4 + (radius4 * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();


	GLfloat x5= -0.78f; GLfloat y5= 0.92f; GLfloat radius5 = 0.02f;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 255);
		glVertex2f(x5, y5); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x5 + (radius5 * cos(i *  twicePi / triangleAmount)),
			    y5 + (radius5 * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();



	GLfloat x6= -0.78f; GLfloat y6= 0.89f; GLfloat radius6 = 0.02f;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 255);
		glVertex2f(x6, y6); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x6 + (radius6 * cos(i *  twicePi / triangleAmount)),
			    y6 + (radius6 * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	glPopMatrix();
	glLoadIdentity();


glFlush();
}




                           //////For Night View////////




 void displayNight() {
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT);

	//background upper
	glBegin(GL_QUADS);
    glColor3ub(0, 0, 51);
	glVertex2f(-1.0f, 1.0f);
	glVertex2f(-1.0f, 0.8f);
	glVertex2f(1.0f, 0.8f);
	glVertex2f(1.0f, 1.0f);
    glEnd();


    //Moon

    int i;
	GLfloat twicePi = 2.0f * PI;

    GLfloat x= -0.6f; GLfloat y= 0.95f; GLfloat radius = 0.03f;
	int triangleAmount = 100;


	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(255, 255, 255);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();


	//upper
	GLfloat x1= -0.62f; GLfloat y1= 0.97f; GLfloat radius1 = 0.04f;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(0, 0, 51);
		glVertex2f(x1, y1); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x1 + (radius1 * cos(i *  twicePi / triangleAmount)),
			    y1 + (radius1 * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();


    //background bottom
    glBegin(GL_QUADS);
    glColor3ub(0, 0, 153);
	glVertex2f(-1.0f, 0.8f);
	glVertex2f(-1.0f, -1.0f);
	glVertex2f(1.0f, -1.0f);
	glVertex2f(1.0f, 0.8f);
    glEnd();





    //BoatSmall
    glPushMatrix();
    glTranslatef(position1,0,0);

    glTranslatef(0.4f,0.85f,0.0f);
    glBegin(GL_QUADS);
    glColor3ub(255, 194, 102);
    glVertex2f(-0.5f, -0.68f);
	glVertex2f(-0.48f, -0.72f);
	glVertex2f(-0.3f, -0.72f);
	glVertex2f(-0.28f, -0.68f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(255, 194, 102);
    glVertex2f(-0.31f, -0.65f);
	glVertex2f(-0.31f, -0.68f);
	glVertex2f(-0.28f, -0.68f);
	glVertex2f(-0.28f, -0.65f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(45, 45, 134);
    glVertex2f(-0.45f, -0.63f);
	glVertex2f(-0.45f, -0.68f);
	glVertex2f(-0.35f, -0.68f);
	glVertex2f(-0.35f, -0.63f);
    glEnd();

    glLineWidth(3);

    glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
	glVertex2f(-0.29f, -0.65f);
	glVertex2f(-0.29f, -0.61f);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(255, 77, 77);
	glVertex2f(-0.29f, -0.61f);
	glVertex2f(-0.29f, -0.64f);
	glVertex2f(-0.26f, -0.63f);
    glEnd();

    glPopMatrix();
    glLoadIdentity();




    //bridge
    glBegin(GL_QUADS);
   glColor3ub(0, 51, 0);
	glVertex2f(-1.0f, 0.75f);
	glVertex2f(-0.9f, 0.75f);
	glVertex2f(-0.9f, 0.8f);
	glVertex2f(-1.0f, 0.8f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.9f, 0.75f);
	glVertex2f(-0.8f, 0.74f);
	glVertex2f(-0.8f, 0.79f);
	glVertex2f(-0.9f, 0.8f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.8f, 0.74f);
	glVertex2f(-0.7f, 0.73f);
	glVertex2f(-0.7f, 0.78f);
	glVertex2f(-0.8f, 0.79f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.7f, 0.73f);
	glVertex2f(-0.6f, 0.71f);
	glVertex2f(-0.6f, 0.77f);
	glVertex2f(-0.7f, 0.78f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.6f, 0.71f);
	glVertex2f(-0.5f, 0.69f);
	glVertex2f(-0.5f, 0.76f);
	glVertex2f(-0.6f, 0.77f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.5f, 0.69f);
	glVertex2f(-0.4f, 0.67f);
	glVertex2f(-0.4f, 0.75f);
	glVertex2f(-0.5f, 0.76f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.4f, 0.67f);
	glVertex2f(-0.3f, 0.64f);
	glVertex2f(-0.3f, 0.74f);
	glVertex2f(-0.4f, 0.75f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.3f, 0.64f);
	glVertex2f(-0.2f, 0.61f);
	glVertex2f(-0.2f, 0.73f);
	glVertex2f(-0.3f, 0.74f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.2f, 0.61f);
	glVertex2f(-0.1f, 0.58f);
	glVertex2f(-0.1f, 0.72f);
	glVertex2f(-0.2f, 0.73f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.1f, 0.58f);
	glVertex2f(0.0f, 0.53f);
	glVertex2f(0.0f, 0.70f);
	glVertex2f(-0.1f, 0.72f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(0.0f, 0.53f);
	glVertex2f(0.1f, 0.47f);
	glVertex2f(0.1f, 0.68f);
	glVertex2f(0.0f, 0.70f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(0.1f, 0.47f);
	glVertex2f(0.2f, 0.40f);
	glVertex2f(0.2f, 0.65f);
	glVertex2f(0.1f, 0.68f);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 51, 0);
    glVertex2f(0.2f, 0.65f);
	glVertex2f(0.2f, 0.40f);
	glVertex2f(0.3f, 0.59f);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 51, 0);
	glVertex2f(0.3f, 0.59f);
	glVertex2f(0.2f, 0.40f);
	glVertex2f(0.5f, 0.4f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(0.5f, 0.4f);
	glVertex2f(0.2f, 0.40f);
	glVertex2f(0.5f, -0.2f);
	glVertex2f(0.9f, -0.2f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(0.5f, -0.2f);
	glVertex2f(0.75f, -1.3f);
	glVertex2f(1.3f, -0.8f);
	glVertex2f(0.9f, -0.2f);
    glEnd();


    //////////////


    //Road separator
    glLineWidth(2);

    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,0.0f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,0.0f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,0.0f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.009f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.005f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.005f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.005f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.007f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.008f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.009f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.01f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.01f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glLineWidth(3);

    glTranslatef(0.05f,-0.01f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();

    glTranslatef(0.05f,-0.01f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-1.0f, 0.77f);
	glVertex2f(-0.99f, 0.77f);
    glEnd();
    glLoadIdentity();

     glLineWidth(3);

    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.01f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.009f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.008f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.008f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.01f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.02f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.03f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.03f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.03f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.03f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.04f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.665f);
    glEnd();

    glTranslatef(0.05f,-0.07f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();


    glTranslatef(0.05f,-0.08f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.05f,-0.08f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.05f,-0.08f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.05f,-0.08f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.05f,-0.08f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.05f,-0.085f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.03f,-0.1f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.03f,-0.1f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.03f,-0.1f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.04f,-0.1f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.04f,-0.1f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.04f,-0.1f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();

    glTranslatef(0.04f,-0.1f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();


    glTranslatef(0.04f,-0.1f,0.0f);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(-0.25f, 0.67f);
	glVertex2f(-0.24f, 0.65f);
    glEnd();
    glLoadIdentity();

    /////////////


    glLineWidth(2);
    //down1
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-1.0f, 0.75f);
	glVertex2f(-0.9f, 0.75f);
    glEnd();

    //up1
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-1.0f, 0.8f);
	glVertex2f(-0.9f, 0.8f);
    glEnd();

    //down2
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.9f, 0.75f);
	glVertex2f(-0.8f, 0.74f);
    glEnd();

    //up2
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.9f, 0.8f);
	glVertex2f(-0.8f, 0.79f);
    glEnd();

    //down3
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.8f, 0.74f);
	glVertex2f(-0.7f, 0.73f);
    glEnd();

    //up3
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.8f, 0.79f);
	glVertex2f(-0.7f, 0.78f);
    glEnd();

    //down4
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.7f, 0.73f);
	glVertex2f(-0.5f, 0.69f);
    glEnd();

    //up4
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.7f, 0.78f);
	glVertex2f(-0.5f, 0.76f);
    glEnd();

    //down5
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.5f, 0.69f);
	glVertex2f(-0.3f, 0.64f);
    glEnd();

    //up5
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.5f, 0.76f);
	glVertex2f(-0.3f, 0.74f);
    glEnd();

    //down6
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.3f, 0.64f);
	glVertex2f(-0.1f, 0.58f);
    glEnd();

    //up6
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.3f, 0.74f);
	glVertex2f(-0.1f, 0.72f);
    glEnd();


    //down7
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.1f, 0.58f);
	glVertex2f(0.1f, 0.47f);
    glEnd();

    //up7
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(-0.1f, 0.72f);
	glVertex2f(0.1f, 0.68f);
    glEnd();


    //down8
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(0.1f, 0.47f);
	glVertex2f(0.2f, 0.4f);
    glEnd();

    //up8
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(0.1f, 0.68f);
	glVertex2f(0.2f, 0.65f);
    glEnd();

    glLineWidth(3);
    //down9
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(0.2f, 0.4f);
	glVertex2f(0.5f, -0.2f);
    glEnd();

    glLineWidth(2);
    //up9
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(0.2f, 0.65f);
	glVertex2f(0.3f, 0.59f);
    glEnd();

    //up9
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(0.3f, 0.59f);
	glVertex2f(0.5f, 0.4f);
    glEnd();

    glLineWidth(3);
    //down9
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(0.5f, -0.2f);
	glVertex2f(0.684f, -1.0f);
    glEnd();

    //up9
    glBegin(GL_LINES);
	glColor3ub(153, 204, 255);
	glVertex2f(0.5f, 0.4f);
	glVertex2f(1.1f, -0.5f);
    glEnd();

    ////////////

    glLineWidth(3);

    //pillar1
    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.98f, 0.745f);
	glVertex2f(-0.96f, 0.72f);
	glVertex2f(-0.94f, 0.72f);
	glVertex2f(-0.92f, 0.745f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.96f, 0.72f);
	glVertex2f(-0.96f, 0.65f);
	glVertex2f(-0.94f, 0.65f);
	glVertex2f(-0.94f, 0.72f);
    glEnd();

    //pillar2
    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.86f, 0.74f);
	glVertex2f(-0.84f, 0.715f);
	glVertex2f(-0.82f, 0.715f);
	glVertex2f(-0.80f, 0.74f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.84f, 0.715f);
	glVertex2f(-0.84f, 0.65f);
	glVertex2f(-0.82f, 0.65f);
	glVertex2f(-0.82f, 0.715f);
    glEnd();
    glLoadIdentity();


    //pillar3
    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.74f, 0.73f);
	glVertex2f(-0.72f, 0.7f);
	glVertex2f(-0.70f, 0.7f);
	glVertex2f(-0.68f, 0.721f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.72f, 0.7f);
	glVertex2f(-0.72f, 0.64f);
	glVertex2f(-0.70f, 0.64f);
	glVertex2f(-0.70f, 0.7f);
    glEnd();


    //pillar4
    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.62f, 0.71f);
	glVertex2f(-0.6f, 0.68f);
	glVertex2f(-0.58f, 0.68f);
	glVertex2f(-0.56f, 0.7f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.6f, 0.68f);
	glVertex2f(-0.6f, 0.62f);
	glVertex2f(-0.58f, 0.62f);
	glVertex2f(-0.58f, 0.68f);
    glEnd();

    //pillar5
    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.50f, 0.685f);
	glVertex2f(-0.48f, 0.66f);
	glVertex2f(-0.46f, 0.655f);
	glVertex2f(-0.44f, 0.67f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.48f, 0.66f);
	glVertex2f(-0.48f, 0.6f);
	glVertex2f(-0.46f, 0.6f);
	glVertex2f(-0.46f, 0.655f);
    glEnd();

    //pillar6
    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.38f, 0.655f);
	glVertex2f(-0.36f, 0.625f);
	glVertex2f(-0.34f, 0.622f);
	glVertex2f(-0.32f, 0.64f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.36f, 0.625f);
	glVertex2f(-0.36f, 0.56f);
	glVertex2f(-0.34f, 0.56f);
	glVertex2f(-0.34f, 0.622f);
    glEnd();

    //pillar7
    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.24f, 0.62f);
	glVertex2f(-0.21f, 0.58f);
	glVertex2f(-0.18f, 0.57f);
	glVertex2f(-0.15f, 0.59f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.21f, 0.58f);
	glVertex2f(-0.21f, 0.5f);
	glVertex2f(-0.18f, 0.5f);
	glVertex2f(-0.18f, 0.57f);
    glEnd();

    //pillar8
    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.05f, 0.55f);
	glVertex2f(-0.02f, 0.485f);
	glVertex2f(0.01f, 0.48f);
	glVertex2f(0.04f, 0.5f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(-0.02f, 0.485f);
	glVertex2f(-0.02f, 0.42f);
	glVertex2f(0.02f, 0.42f);
	glVertex2f(0.02f, 0.49f);
    glEnd();

    //pillar9
    glBegin(GL_TRIANGLES);
    glColor3ub(0, 51, 0);
    glVertex2f(0.1f, 0.465f);
	glVertex2f(0.13f, 0.4f);
	glVertex2f(0.2f, 0.395f);
	glEnd();

	glBegin(GL_QUADS);
    glColor3ub(0, 51, 0);
	glVertex2f(0.13f, 0.4f);
	glVertex2f(0.13f, 0.3f);
	glVertex2f(0.2f, 0.3f);
	glVertex2f(0.2f, 0.395f);
    glEnd();

    //pillar9
    glBegin(GL_TRIANGLES);
    glColor3ub(0, 51, 0);
    glVertex2f(0.31f, 0.17f);
	glVertex2f(0.31f, -0.01f);
	glVertex2f(0.385f, 0.02f);
	glEnd();

	//pillar10
    glBegin(GL_TRIANGLES);
    glColor3ub(0, 51, 0);
    glVertex2f(0.5f, -0.22f);
	glVertex2f(0.5f, -0.39f);
	glVertex2f(0.54f, -0.38f);
	glEnd();


	/////////////

	//electricity pillar
	glLineWidth(2);

	//up1
	glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.98f, 0.85f);
	glVertex2f(-0.98f, 0.8f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.99f, 0.84f);
	glVertex2f(-0.97f, 0.86f);
    glEnd();

    //up2
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.92f, 0.85f);
	glVertex2f(-0.92f, 0.8f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.93f, 0.84f);
	glVertex2f(-0.91f, 0.86f);
    glEnd();

    //up3
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.86f, 0.85f);
	glVertex2f(-0.86f, 0.8f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.87f, 0.84f);
	glVertex2f(-0.85f, 0.86f);
    glEnd();

    //up4
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.80f, 0.85f);
	glVertex2f(-0.80f, 0.79f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.81f, 0.84f);
	glVertex2f(-0.79f, 0.86f);
    glEnd();

    //up5
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.74f, 0.85f);
	glVertex2f(-0.74f, 0.78f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.75f, 0.84f);
	glVertex2f(-0.73f, 0.86f);
    glEnd();


    //up6
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.67f, 0.85f);
	glVertex2f(-0.67f, 0.77f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.68f, 0.84f);
	glVertex2f(-0.66f, 0.86f);
    glEnd();


    //up7
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.60f, 0.85f);
	glVertex2f(-0.60f, 0.76f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.61f, 0.84f);
	glVertex2f(-0.59f, 0.86f);
    glEnd();



    //up8
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.51f, 0.85f);
	glVertex2f(-0.51f, 0.75f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.52f, 0.84f);
	glVertex2f(-0.50f, 0.86f);
    glEnd();

    //up9
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.41f, 0.85f);
	glVertex2f(-0.41f, 0.74f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.42f, 0.84f);
	glVertex2f(-0.40f, 0.86f);
    glEnd();

    //up10
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.30f, 0.85f);
	glVertex2f(-0.30f, 0.73f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.31f, 0.84f);
	glVertex2f(-0.29f, 0.86f);
    glEnd();

    //up11
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.18f, 0.85f);
	glVertex2f(-0.18f, 0.72f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.19f, 0.84f);
	glVertex2f(-0.17f, 0.86f);
    glEnd();


    //up12
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.06f, 0.85f);
	glVertex2f(-0.06f, 0.71f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.07f, 0.84f);
	glVertex2f(-0.05f, 0.86f);
    glEnd();

    //up13
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.06f, 0.85f);
	glVertex2f(0.06f, 0.69f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.05f, 0.84f);
	glVertex2f(0.07f, 0.86f);
    glEnd();


    //up14
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.20f, 0.85f);
	glVertex2f(0.20f, 0.64f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.18f, 0.84f);
	glVertex2f(0.22f, 0.86f);
    glEnd();

    //up15
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.32f, 0.83f);
	glVertex2f(0.32f, 0.57f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.30f, 0.82f);
	glVertex2f(0.34f, 0.84f);
    glEnd();

    //up16
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.44f, 0.76f);
	glVertex2f(0.44f, 0.46f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.42f, 0.75f);
	glVertex2f(0.46f, 0.77f);
    glEnd();


    //up17
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.58f, 0.63f);
	glVertex2f(0.58f, 0.28f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.55f, 0.61f);
	glVertex2f(0.61f, 0.66f);
    glEnd();


    //up18
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.72f, 0.44f);
	glVertex2f(0.72f, 0.07f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.69f, 0.42f);
	glVertex2f(0.76f, 0.47f);
    glEnd();

    //up19
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.87f, 0.3f);
	glVertex2f(0.87f, -0.15f);
    glEnd();
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.83f, 0.27f);
	glVertex2f(0.9f, 0.32f);
    glEnd();


    //////////


    //wire
    glLineWidth(0.5);

    //down1
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-1.0f, 0.84f);
	glVertex2f(-0.93f, 0.84f);
    glEnd();

    //up1
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-1.0f, 0.86f);
	glVertex2f(-0.91f, 0.86f);
    glEnd();

    //down2
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.93f, 0.84f);
	glVertex2f(-0.87f, 0.84f);
    glEnd();

    //up2
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.91f, 0.86f);
	glVertex2f(-0.85f, 0.86f);
    glEnd();

    //down3
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.87f, 0.84f);
	glVertex2f(-0.81f, 0.84f);
    glEnd();

    //up3
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
    glVertex2f(-0.85f, 0.86f);
	glVertex2f(-0.79f, 0.86f);
    glEnd();

    //down4
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.81f, 0.84f);
	glVertex2f(-0.75f, 0.84f);
    glEnd();

    //up4
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.79f, 0.86f);
	glVertex2f(-0.73f, 0.86f);
    glEnd();

    //down5
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.75f, 0.84f);
	glVertex2f(-0.68f, 0.84f);
    glEnd();

    //up5
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.73f, 0.86f);
	glVertex2f(-0.66f, 0.86f);
    glEnd();

    //down6
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.75f, 0.84f);
	glVertex2f(-0.68f, 0.84f);
    glEnd();

    //up6
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.73f, 0.86f);
	glVertex2f(-0.66f, 0.86f);
    glEnd();

    //down7
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.68f, 0.84f);
	glVertex2f(-0.61f, 0.84f);
    glEnd();

    //up7
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.66f, 0.86f);
	glVertex2f(-0.59f, 0.86f);
    glEnd();

    //down8
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.61f, 0.84f);
	glVertex2f(-0.52f, 0.84f);
    glEnd();

    //up8
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.59f, 0.86f);
	glVertex2f(-0.50f, 0.86f);
    glEnd();


    //down9
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.52f, 0.84f);
	glVertex2f(-0.42f, 0.84f);
    glEnd();

    //up9
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.50f, 0.86f);
	glVertex2f(-0.40f, 0.86f);
    glEnd();

    //down10
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.42f, 0.84f);
	glVertex2f(-0.31f, 0.84f);
    glEnd();

    //up10
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.40f, 0.86f);
	glVertex2f(-0.29f, 0.86f);
    glEnd();

    //down11
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.31f, 0.84f);
	glVertex2f(-0.19f, 0.84f);
    glEnd();

    //up11
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
    glVertex2f(-0.29f, 0.86f);
	glVertex2f(-0.17f, 0.86f);
    glEnd();

    //down12
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.19f, 0.84f);
	glVertex2f(-0.07f, 0.84f);
    glEnd();

    //up12
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.17f, 0.86f);
	glVertex2f(-0.05f, 0.86f);
    glEnd();

    //down13
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.07f, 0.84f);
	glVertex2f(0.05f, 0.84f);
    glEnd();

    //up13
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(-0.05f, 0.86f);
	glVertex2f(0.07f, 0.86f);
    glEnd();

    //down14
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.05f, 0.84f);
	glVertex2f(0.18f, 0.84f);
    glEnd();

    //up14
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.07f, 0.86f);
	glVertex2f(0.22f, 0.86f);
    glEnd();

    //down15
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.18f, 0.84f);
	glVertex2f(0.30f, 0.82f);
    glEnd();

    //up15
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.22f, 0.86f);
	glVertex2f(0.34f, 0.84f);
    glEnd();

    //down16
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.30f, 0.82f);
	glVertex2f(0.42f, 0.75f);
    glEnd();

    //up16
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.34f, 0.84f);
	glVertex2f(0.46f, 0.77f);
    glEnd();

    //down17
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.42f, 0.75f);
	glVertex2f(0.55f, 0.61f);
    glEnd();

    //up17
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.46f, 0.77f);
	glVertex2f(0.61f, 0.66f);
    glEnd();

    //down18
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.55f, 0.61f);
	glVertex2f(0.69f, 0.42f);
    glEnd();

    //up18
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.61f, 0.66f);
	glVertex2f(0.76f, 0.47f);
    glEnd();

   //down19
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.69f, 0.42f);
	glVertex2f(0.83f, 0.27f);
    glEnd();

    //up19
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.76f, 0.47f);
	glVertex2f(0.9f, 0.32f);
    glEnd();

    //down20
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(0.83f, 0.27f);
	glVertex2f(1.0f, 0.1f);
    glEnd();

    //up20
    glBegin(GL_LINES);
	glColor3ub(0, 0, 102);
	glVertex2f(1.0f, 0.24f);
	glVertex2f(0.9f, 0.32f);
    glEnd();


    ///////


    //Bus2


    glPushMatrix();
    glTranslatef(position5,position4,0);
    glTranslatef(-0.17f,1.0f,0.0f);
    //top
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 102);
	glVertex2f(0.7f, -0.7f);
	glVertex2f(0.75f, -0.85f);
	glVertex2f(0.8f, -0.83f);
	glVertex2f(0.73f, -0.69f);
    glEnd();


    //side
    glBegin(GL_QUADS);
    glColor3ub(102, 0, 204);
	glVertex2f(0.7f, -0.7f);
	glVertex2f(0.7f, -0.78f);
	glVertex2f(0.75f, -0.95f);
	glVertex2f(0.75f, -0.85f);
    glEnd();


    //back
    glBegin(GL_QUADS);
    glColor3ub(179, 255, 204);
	glVertex2f(0.75f, -0.85f);
	glVertex2f(0.75f, -0.95f);
	glVertex2f(0.8f, -0.93f);
	glVertex2f(0.8f, -0.83f);
    glEnd();


    //backBottom
    glBegin(GL_QUADS);
    glColor3ub(179, 255, 204);
	glVertex2f(0.75f, -0.85f);
	glVertex2f(0.75f, -0.89f);
	glVertex2f(0.8f, -0.87f);
	glVertex2f(0.8f, -0.83f);
    glEnd();

    //BusWheel
	glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(0.71f, -0.81f);
	glVertex2f(0.71f, -0.82f);
    glEnd();


    glBegin(GL_LINES);
	glColor3ub(255, 255, 204);
	glVertex2f(0.73f, -0.88f);
	glVertex2f(0.73f, -0.89f);
    glEnd();
    glPopMatrix();
    glLoadIdentity();



    //Lamp

    //lamp1
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.95f, 0.8f);
	glVertex2f(-0.95f, 0.75f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.95f, 0.8f);
	glVertex2f(-0.94f, 0.81f);
    glEnd();

    //lamp1_Light
    glBegin(GL_TRIANGLES);
	glColor3ub(255, 255, 179);
	glVertex2f(-0.94f, 0.81f);
	glVertex2f(-0.94f, 0.76f);
	glVertex2f(-0.93f, 0.78f);
    glEnd();

    //lamp2
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.89f, 0.8f);
	glVertex2f(-0.89f, 0.75f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.89f, 0.8f);
	glVertex2f(-0.88f, 0.81f);
    glEnd();

    //lamp2_Light
    glBegin(GL_TRIANGLES);
	glColor3ub(255, 255, 179);
	glVertex2f(-0.88f, 0.81f);
	glVertex2f(-0.88f, 0.76f);
	glVertex2f(-0.87f, 0.78f);
    glEnd();

    //lamp3
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.83f, 0.8f);
	glVertex2f(-0.83f, 0.74f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.83f, 0.8f);
	glVertex2f(-0.82f, 0.81f);
    glEnd();

    //lamp3_Light
    glBegin(GL_TRIANGLES);
	glColor3ub(255, 255, 179);
	glVertex2f(-0.82f, 0.81f);
	glVertex2f(-0.82f, 0.76f);
	glVertex2f(-0.81f, 0.78f);
    glEnd();


    //lamp4
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.77f, 0.8f);
	glVertex2f(-0.77f, 0.74f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.77f, 0.8f);
	glVertex2f(-0.76f, 0.81f);
    glEnd();

    //lamp4_Light
    glBegin(GL_TRIANGLES);
	glColor3ub(255, 255, 179);
	glVertex2f(-0.76f, 0.81f);
	glVertex2f(-0.76f, 0.76f);
	glVertex2f(-0.75f, 0.78f);
    glEnd();



    //lamp5
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.71f, 0.8f);
	glVertex2f(-0.71f, 0.73f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.71f, 0.8f);
	glVertex2f(-0.7f, 0.81f);
    glEnd();

     //lamp5_Light
    glBegin(GL_TRIANGLES);
	glColor3ub(255, 255, 179);
	glVertex2f(-0.7f, 0.81f);
	glVertex2f(-0.7f, 0.76f);
	glVertex2f(-0.69f, 0.78f);
    glEnd();


    //lamp6
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.64f, 0.8f);
	glVertex2f(-0.64f, 0.72f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.64f, 0.8f);
	glVertex2f(-0.63, 0.81f);
    glEnd();

     //lamp6_Light
    glBegin(GL_TRIANGLES);
	glColor3ub(255, 255, 179);
	glVertex2f(-0.63f, 0.81f);
	glVertex2f(-0.63f, 0.75f);
	glVertex2f(-0.62, 0.77f);
    glEnd();


    //lamp7
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.56f, 0.8f);
	glVertex2f(-0.56f, 0.70f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.56f, 0.8f);
	glVertex2f(-0.55, 0.81f);
    glEnd();

    //lamp7_Light
    glBegin(GL_TRIANGLES);
	glColor3ub(255, 255, 179);
	glVertex2f(-0.55f, 0.81f);
	glVertex2f(-0.55f, 0.74f);
	glVertex2f(-0.535, 0.76f);
    glEnd();


    //lamp8
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.47f, 0.8f);
	glVertex2f(-0.47f, 0.68f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.47f, 0.8f);
	glVertex2f(-0.46, 0.81f);
    glEnd();

    //lamp8_Light
    glBegin(GL_TRIANGLES);
	glColor3ub(255, 255, 179);
	glVertex2f(-0.46f, 0.81f);
	glVertex2f(-0.46f, 0.73f);
	glVertex2f(-0.44, 0.75f);
    glEnd();


    //lamp9
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.35f, 0.8f);
	glVertex2f(-0.35f, 0.65f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.35f, 0.8f);
	glVertex2f(-0.33, 0.82f);
    glEnd();

    //lamp9_Light
    glBegin(GL_TRIANGLES);
	glColor3ub(255, 255, 179);
	glVertex2f(-0.34f, 0.81f);
	glVertex2f(-0.34f, 0.71f);
	glVertex2f(-0.32, 0.73f);
    glEnd();

    //lamp10
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.24f, 0.8f);
	glVertex2f(-0.24f, 0.62f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.24f, 0.8f);
	glVertex2f(-0.22, 0.82f);
    glEnd();

    //lamp10_Light
    glBegin(GL_TRIANGLES);
	glColor3ub(255, 255, 179);
	glVertex2f(-0.23f, 0.81f);
	glVertex2f(-0.23f, 0.7f);
	glVertex2f(-0.21, 0.72f);
    glEnd();


    //lamp11
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.12f, 0.8f);
	glVertex2f(-0.12f, 0.59f);
    glEnd();

    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.12f, 0.8f);
	glVertex2f(-0.10, 0.82f);
    glEnd();

    //lamp11_Light
    glBegin(GL_TRIANGLES);
	glColor3ub(255, 255, 179);
	glVertex2f(-0.11f, 0.81f);
	glVertex2f(-0.11f, 0.7f);
	glVertex2f(-0.09, 0.72f);
    glEnd();

    //lamp12
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(-0.0f, 0.8f);
	glVertex2f(-0.0f, 0.53f);
    glEnd();

    glLineWidth(4);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.0f, 0.8f);
	glVertex2f(0.03, 0.83f);
    glEnd();

    //lamp12_Light
    glBegin(GL_TRIANGLES);
	glColor3ub(255, 255, 179);
	glVertex2f(0.01f, 0.82f);
	glVertex2f(0.01f, 0.68f);
	glVertex2f(0.04, 0.7f);
    glEnd();

    //lamp13
    glLineWidth(2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.13f, 0.8f);
	glVertex2f(0.13f, 0.45f);
    glEnd();

    glLineWidth(4);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.13f, 0.8f);
	glVertex2f(0.16, 0.83f);
    glEnd();

    //lamp13_Light
    glBegin(GL_TRIANGLES);
	glColor3ub(255, 255, 179);
	glVertex2f(0.14f, 0.82f);
	glVertex2f(0.14f, 0.62f);
	glVertex2f(0.18, 0.65f);
    glEnd();


    //lamp14
    glLineWidth(2.2);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.25f, 0.69f);
	glVertex2f(0.25f, 0.30f);
    glEnd();

    glLineWidth(5);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.25f, 0.69f);
	glVertex2f(0.29, 0.75f);
    glEnd();

     //lamp14_Light
    glBegin(GL_TRIANGLES);
	glColor3ub(255, 255, 179);
	glVertex2f(0.27f, 0.72f);
	glVertex2f(0.26f, 0.5f);
	glVertex2f(0.3, 0.53f);
    glEnd();


    //lamp15
    glLineWidth(2.5);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.35f, 0.6f);
	glVertex2f(0.35f, 0.1f);
    glEnd();

    glLineWidth(5);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.35f, 0.6f);
	glVertex2f(0.39, 0.66f);
    glEnd();

    //lamp15_Light
    glBegin(GL_TRIANGLES);
	glColor3ub(255, 255, 179);
	glVertex2f(0.37f, 0.63f);
	glVertex2f(0.36f, 0.35f);
	glVertex2f(0.40, 0.4f);
    glEnd();


    //lamp16
    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.47f, 0.45f);
	glVertex2f(0.47f, -0.14f);
    glEnd();

    glLineWidth(6);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.47f, 0.45f);
	glVertex2f(0.52, 0.53f);
    glEnd();

    //lamp16_Light
    glBegin(GL_TRIANGLES);
	glColor3ub(255, 255, 179);
	glVertex2f(0.50f, 0.50f);
	glVertex2f(0.48f, 0.1f);
	glVertex2f(0.55, 0.15f);
    glEnd();


    //lamp17
    glLineWidth(3);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.6f, 0.1f);
	glVertex2f(0.6f, -0.62f);
    glEnd();

    glLineWidth(7);
    glBegin(GL_LINES);
	glColor3ub(255, 255, 0);
	glVertex2f(0.6f, 0.1f);
	glVertex2f(0.65, 0.21f);
    glEnd();

    //lamp17_Light
    glBegin(GL_TRIANGLES);
	glColor3ub(255, 255, 179);
	glVertex2f(0.63f, 0.16f);
	glVertex2f(0.61f, -0.35f);
	glVertex2f(0.7, -0.25f);
    glEnd();



    //Stars
	glPointSize(3);
    glColor3ub(255, 255, 255);
    glBegin(GL_POINTS);
    glVertex2f(0.8f, 0.9f);
    glEnd();

    glPointSize(3);
    glColor3ub(255, 255, 255);
    glBegin(GL_POINTS);
    glVertex2f(0.5f, 0.88f);
    glEnd();

    glPointSize(1);
    glColor3ub(255, 255, 255);
    glBegin(GL_POINTS);
    glVertex2f(0.0f, 0.99f);
    glEnd();

    glPointSize(2);
    glColor3ub(255, 255, 255);
    glBegin(GL_POINTS);
    glVertex2f(-0.5f, 0.9f);
    glEnd();

    glPointSize(3);
    glColor3ub(255, 255, 255);
    glBegin(GL_POINTS);
    glVertex2f(-0.7f, 0.87f);
    glEnd();

    glPointSize(3);
    glColor3ub(255, 255, 255);
    glBegin(GL_POINTS);
    glVertex2f(-0.2f, 0.87f);
    glEnd();



glFlush();
}



void displayDayRain(){
    displayDay();
    displayRain();

glFlush();
}
void displayEveningRain(){
    displayEvening();
    displayRain();

glFlush();
}

void displayNightRain(){
    displayNight();
    displayRain();

glFlush();
}


void sound()
{

    PlaySound("rain.wav", NULL, SND_ASYNC|SND_FILENAME|SND_LOOP);


}

void sound2()
{

    PlaySound("plane.wav", NULL, SND_ASYNC|SND_FILENAME|SND_LOOP);


}
void sound3()
{

    PlaySound("empty.wav", NULL, SND_ASYNC|SND_FILENAME|SND_LOOP);


}

//used for Plane speed control
void handleMouse(int button, int state, int x, int y) {
	if (button == GLUT_LEFT_BUTTON){
			speed2 += 0.02f;
			}
			if (button == GLUT_RIGHT_BUTTON)
	{speed2 -= 0.02f;
			}
	glutPostRedisplay();
	}
//used for Boat/Bus speed control
void handleKeypress(unsigned char key, int x, int y) {
	switch (key) {

case 'b': //To Stop the Boat
    speed = 0.0f;
    break;
case 'c': //To Start the Boat
    speed = 0.01f;
    break;
case 'o': //To Stop the Bus
    speed1 = 0.0f;
    break;
case 'p': //To Start the Bus
    speed1 = 0.003f;
    break;
case 'n': glutDisplayFunc(displayNight); //To display Night View
sound3();
    break;
case 'd': glutDisplayFunc(displayDay);  //To display Day View
sound2();
    break;
case 'e': glutDisplayFunc(displayEvening);  //To display Evening View
sound3();
    break;
case 'r': glutDisplayFunc(displayDayRain);  //To display Night Rain View
sound();
    break;
case 't': glutDisplayFunc(displayEveningRain);  //To display Night Rain View
sound();
    break;
case 'y': glutDisplayFunc(displayNightRain);  //To display Night Rain View
sound();

    break;

glutPostRedisplay();
 }
 }
int main(int argc, char** argv) {
    cout << "       Jamuna Bridge" << endl<< endl;
    cout << "Press b : To Stop the Boat" << endl;
    cout << "Press c : To Start the Boat" << endl;
    cout << "Press o : To Stop the Car" << endl;
    cout << "Press p : To Start the Car" << endl;
    cout << "Press Mouse Left Key : To Speed up the Plane" << endl;
    cout << "Press Mouse Right Key : To Speed down the Plane" << endl;
    cout << "Press d : To Display the Day View" << endl;
    cout << "Press e : To Display the Evening View" << endl;
    cout << "Press n : To Display the Night View" << endl;
    cout << "Press r : To Display the Day with Rain View" << endl;
    cout << "Press t : To Display the Evening with Rain View" << endl;
    cout << "Press y : To Display the Night with Rain View" << endl;

    cout << " " << endl<< endl;
    cout << "     Group Members" << endl<< endl;
    cout << "Rakib Hasan             18-36096-1" << endl;
    cout << "Afsana Akter Bristy     18-36787-1" << endl;
    cout << "Jannatun Nayim Supti    18-37594-1" << endl;
    cout << "Ahsun Mahmud Riad       18-36814-1" << endl;

	glutInit(&argc, argv);
	glutCreateWindow("Jamuna Bridge || Press e: Evening View | Press n: Night View | Press r: Day+Rain View  | Press t: Evening+Rain View | Press y: Night+Rain View| Press d: Day View");
    glutInitWindowSize (1300, 650);
	glutDisplayFunc(displayDay);
	sound2();
	glutTimerFunc(100, update, 0);
	glutTimerFunc(100, update1, 0);
	glutTimerFunc(100, update2, 0);
	glutTimerFunc(100, update4, 0);
	glutTimerFunc(100, update5, 0);
	glutTimerFunc(100, update6, 0);
	glutTimerFunc(100, update7, 0);
	glutTimerFunc(100, updateRain, 0);
	glutTimerFunc(100, updateCloud, 0);
	glutKeyboardFunc(handleKeypress);
	glutMouseFunc(handleMouse);
	glutIdleFunc(Idle);
	glutMainLoop();
	return 0;
}
